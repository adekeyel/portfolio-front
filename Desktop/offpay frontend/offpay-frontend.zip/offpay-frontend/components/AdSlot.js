'use client';
import { useEffect, useState } from 'react';
import { apiFetch, API_URL } from '../lib/api';

const ROTATE_MS = 2 * 60 * 1000; // 2 minutes, per spec

// media_url comes back as a relative path like "/uploads/ads/xyz.png" — resolve
// it against the API's origin (not the frontend's), since that's where the
// file is actually served from.
const API_ORIGIN = API_URL.replace(/\/api\/?$/, '');

/**
 * Reserves a 320x100 ad space and rotates through whatever active ads the
 * super admin has targeted at this page+position. Renders nothing (not even
 * the placeholder box) when there are no ads configured for this slot, so an
 * empty slot never leaves a visible gap in the layout.
 */
export default function AdSlot({ page = 'dashboard', slot = 'middle' }) {
  const [ads, setAds] = useState([]);
  const [index, setIndex] = useState(0);

  useEffect(() => {
    apiFetch(`/ads?page=${page}&position=${slot}`)
      .then((res) => {
        const data = res.data || [];
        setAds(data);
        setIndex(data.length ? Math.floor(Math.random() * data.length) : 0);
      })
      .catch(() => setAds([]));
  }, [page, slot]);

  useEffect(() => {
    if (ads.length < 2) return;
    const timer = setInterval(() => setIndex((i) => (i + 1) % ads.length), ROTATE_MS);
    return () => clearInterval(timer);
  }, [ads.length]);

  if (ads.length === 0) return null;
  const ad = ads[index % ads.length];
  const src = ad.media_url.startsWith('http') ? ad.media_url : `${API_ORIGIN}${ad.media_url}`;

  const media = ad.media_type === 'video' ? (
    <video src={src} className="h-full w-full object-cover" autoPlay muted loop playsInline />
  ) : (
    // eslint-disable-next-line @next/next/no-img-element
    <img src={src} alt={ad.title} className="h-full w-full object-cover" />
  );

  return (
    <div
      className="mx-auto overflow-hidden rounded-lg border border-line"
      style={{ width: 320, height: 100, maxWidth: '100%' }}
      data-ad-page={page}
      data-ad-slot={slot}
    >
      {ad.link_url ? <a href={ad.link_url} target="_blank" rel="noopener noreferrer">{media}</a> : media}
    </div>
  );
}
