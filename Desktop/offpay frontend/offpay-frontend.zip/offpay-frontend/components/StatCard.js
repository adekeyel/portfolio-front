export default function StatCard({ label, value, sub, accent = 'ink' }) {
  const accentColor = { ink: 'text-ink', unlock: 'text-unlock', lock: 'text-lock', danger: 'text-danger' }[accent];
  return (
    <div className="rounded-xl2 border border-line bg-white p-5 shadow-card">
      <p className="text-xs uppercase tracking-wide text-slate">{label}</p>
      <p className={`mt-2 font-mono text-2xl font-semibold ${accentColor}`}>{value}</p>
      {sub && <p className="mt-1 text-xs text-slate">{sub}</p>}
    </div>
  );
}
