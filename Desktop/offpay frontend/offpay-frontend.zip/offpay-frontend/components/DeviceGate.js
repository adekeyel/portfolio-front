'use client';
import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { hasKnownDevice, isUnlockedThisSession } from '../lib/api';

/**
 * Renders nothing — just makes sure a device that has ever logged in never
 * lands back on the marketing page. If it's known but locked, straight to
 * the PIN/fingerprint unlock screen; if already unlocked this session,
 * straight to the dashboard. A genuinely new visitor sees the marketing
 * page underneath as normal.
 */
export default function DeviceGate() {
  const router = useRouter();

  useEffect(() => {
    if (!hasKnownDevice()) return;
    router.replace(isUnlockedThisSession() ? '/dashboard' : '/auth/unlock');
  }, [router]);

  return null;
}
