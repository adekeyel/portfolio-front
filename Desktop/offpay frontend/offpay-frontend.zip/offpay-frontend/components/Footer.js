import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="border-t border-line bg-ink text-white">
      <div className="mx-auto max-w-6xl px-6 py-12 grid gap-10 md:grid-cols-4">
        <div>
          <p className="font-display text-lg font-semibold">Off<span className="text-unlock">Pay</span></p>
          <p className="mt-3 text-sm text-white/60">Money that moves, even offline.</p>
        </div>
        <div>
          <p className="text-xs uppercase tracking-wide text-white/40">Company</p>
          <ul className="mt-3 space-y-2 text-sm text-white/70">
            <li><Link href="/about">About</Link></li>
            <li><Link href="/support">Support</Link></li>
          </ul>
        </div>
        <div>
          <p className="text-xs uppercase tracking-wide text-white/40">Legal</p>
          <ul className="mt-3 space-y-2 text-sm text-white/70">
            <li><Link href="/terms">Terms of Service</Link></li>
            <li><Link href="/privacy">Privacy Policy</Link></li>
          </ul>
        </div>
        <div>
          <p className="text-xs uppercase tracking-wide text-white/40">Get started</p>
          <ul className="mt-3 space-y-2 text-sm text-white/70">
            <li><Link href="/auth/register">Open an account</Link></li>
            <li><Link href="/auth/login">Log in</Link></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-white/10 px-6 py-5 text-center text-xs text-white/40">
        © {new Date().getFullYear()} OffPay Technologies Ltd. All rights reserved.
      </div>
    </footer>
  );
}
