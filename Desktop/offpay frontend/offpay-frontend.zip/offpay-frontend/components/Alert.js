export default function Alert({ type = 'info', children }) {
  const styles = {
    info: 'bg-ink/5 text-ink border-ink/10',
    success: 'bg-unlock-dim text-ink border-unlock/30',
    warning: 'bg-lock-dim text-ink border-lock/40',
    error: 'bg-red-50 text-danger border-danger/30',
  };
  return <div className={`rounded-lg border px-4 py-3 text-sm ${styles[type]}`}>{children}</div>;
}
