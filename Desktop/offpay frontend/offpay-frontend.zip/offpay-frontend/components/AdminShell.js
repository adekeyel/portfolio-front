'use client';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { getAdminInfo, clearAdminSession } from '../lib/adminApi';

// Every role also implicitly includes 'overview' and 'notifications' (added below).
const NAV_BY_ROLE = {
  admin: ['overview', 'kyc', 'tierUpgrades', 'accounts', 'transactions', 'wallet', 'fraud', 'recovery', 'support', 'audit', 'createUser', 'staff', 'closedAccounts', 'ads', 'settings', 'notifications'],
  compliance: ['overview', 'kyc', 'tierUpgrades', 'accounts', 'audit', 'closedAccounts', 'notifications'],
  finance: ['overview', 'accounts', 'transactions', 'wallet', 'notifications'],
  support: ['overview', 'accounts', 'tierUpgrades', 'support', 'notifications'],
  fraud: ['overview', 'fraud', 'transactions', 'accounts', 'notifications'],
  recovery: ['overview', 'recovery', 'accounts', 'notifications'],
  operations: ['overview', 'accounts', 'notifications'],
};

const ITEMS = {
  overview: { href: '/admin/dashboard', label: 'Overview', icon: '◎' },
  kyc: { href: '/admin/kyc', label: 'KYC review', icon: '✓' },
  tierUpgrades: { href: '/admin/tier-upgrades', label: 'Tier upgrades', icon: '⇧' },
  accounts: { href: '/admin/users', label: 'Accounts', icon: '☰' },
  transactions: { href: '/admin/transactions', label: 'Transactions', icon: '⇄' },
  wallet: { href: '/admin/wallet', label: 'Wallet', icon: '₦' },
  fraud: { href: '/admin/fraud', label: 'Fraud monitoring', icon: '⚠' },
  recovery: { href: '/admin/recovery', label: 'Recovery center', icon: '⟲' },
  support: { href: '/admin/support', label: 'Support', icon: '✉' },
  audit: { href: '/admin/audit-logs', label: 'Audit logs', icon: '⎘' },
  createUser: { href: '/admin/create-user', label: 'Create users', icon: '+' },
  staff: { href: '/admin/staff', label: 'Staff', icon: '⚑' },
  closedAccounts: { href: '/admin/closed-accounts', label: 'Closed accounts', icon: '⊘' },
  ads: { href: '/admin/ads', label: 'Ads', icon: '🖼' },
  settings: { href: '/admin/settings', label: 'Settings', icon: '⚙' },
  notifications: { href: '/admin/notifications', label: 'Notifications', icon: '🔔' },
};

export default function AdminShell({ children }) {
  const pathname = usePathname();
  const router = useRouter();
  const [admin, setAdmin] = useState(null);

  useEffect(() => {
    const info = getAdminInfo();
    if (!info) {
      router.push('/admin/login');
    } else {
      setAdmin(info);
    }
  }, [router]);

  function handleLogout() {
    clearAdminSession();
    router.push('/admin/login');
  }

  if (!admin) return null;
  const visibleKeys = NAV_BY_ROLE[admin.role] || ['overview', 'notifications'];

  return (
    <div className="min-h-screen bg-paper md:flex">
      <aside className="hidden w-64 shrink-0 flex-col border-r border-line bg-ink md:flex">
        <div className="border-b border-white/10 px-6 py-5">
          <p className="font-display text-lg font-semibold text-white">Off<span className="text-lock">Pay</span></p>
          <p className="mt-0.5 text-xs uppercase tracking-wide text-white/50">Admin · {admin.role === 'admin' ? 'super admin' : admin.role}</p>
        </div>
        <nav className="flex-1 space-y-1 overflow-y-auto px-3 py-4">
          {visibleKeys.map((key) => {
            const item = ITEMS[key];
            if (!item) return null;
            return (
              <Link
                key={key}
                href={item.href}
                className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium ${
                  pathname === item.href ? 'bg-white text-ink' : 'text-white/75 hover:bg-white/10'
                }`}
              >
                <span aria-hidden>{item.icon}</span>
                {item.label}
              </Link>
            );
          })}
        </nav>
        <div className="border-t border-white/10 p-3">
          <p className="px-3 py-1 text-xs text-white/50">{admin.email}</p>
          <button onClick={handleLogout} className="w-full rounded-lg px-3 py-2.5 text-left text-sm font-medium text-lock hover:bg-white/10">
            Log out
          </button>
        </div>
      </aside>
      <main className="flex-1 px-6 py-8 md:px-10">{children}</main>
    </div>
  );
}
