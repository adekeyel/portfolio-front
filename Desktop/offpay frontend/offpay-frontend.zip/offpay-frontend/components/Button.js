export default function Button({ children, variant = 'primary', className = '', ...props }) {
  const base = 'inline-flex items-center justify-center rounded-lg px-5 py-2.5 text-sm font-semibold transition-colors disabled:opacity-50 disabled:cursor-not-allowed';
  const variants = {
    primary: 'bg-ink text-white hover:bg-ink-700',
    accent: 'bg-unlock text-white hover:opacity-90',
    ghost: 'bg-transparent text-ink border border-line hover:bg-white',
    danger: 'bg-danger text-white hover:opacity-90',
    link: 'bg-transparent text-ink underline underline-offset-4 px-0 py-0',
  };
  return (
    <button className={`${base} ${variants[variant]} ${className}`} {...props}>
      {children}
    </button>
  );
}
