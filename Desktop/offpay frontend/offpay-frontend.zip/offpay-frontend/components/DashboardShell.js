'use client';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { usePathname, useRouter } from 'next/navigation';
import { clearSession, hasKnownDevice, isUnlockedThisSession } from '../lib/api';

// Top-level sections match OPay's bottom tab bar: Home, Rewards, Finance, Cards, Me.
// Send/Receive/Transactions/Statement/Offline-mode live one level down, reached
// from Home's quick actions or the Finance hub, the same way OPay itself does it.
const NAV = [
  { href: '/dashboard', label: 'Home', icon: 'home' },
  { href: '/dashboard/rewards', label: 'Rewards', icon: 'rewards' },
  { href: '/dashboard/finance', label: 'Finance', icon: 'finance' },
  { href: '/dashboard/cards', label: 'Cards', icon: 'cards' },
  { href: '/dashboard/settings', label: 'Me', icon: 'me' },
];

export default function DashboardShell({ children }) {
  const pathname = usePathname();
  const router = useRouter();
  const [ready, setReady] = useState(false);

  // Every dashboard page renders through here, so this is the one place that
  // guarantees: a device that was ever logged in never gets bounced to the
  // marketing landing page or a full password login again — it only ever
  // needs the lightweight PIN/fingerprint unlock, unless the session itself
  // has genuinely expired (no refresh token at all).
  useEffect(() => {
    if (!hasKnownDevice()) {
      router.replace('/');
      return;
    }
    if (!isUnlockedThisSession()) {
      router.replace(`/auth/unlock?next=${encodeURIComponent(pathname)}`);
      return;
    }
    setReady(true);
  }, [pathname, router]);

  function handleLogout() {
    clearSession();
    router.push('/auth/login');
  }

  if (!ready) return null;

  return (
    <div className="min-h-screen bg-paper md:flex">
      <aside className="hidden w-64 shrink-0 flex-col border-r border-line bg-white md:flex">
        <div className="px-6 py-6">
          <Link href="/dashboard" className="font-display text-xl font-semibold text-ink">
            Off<span className="text-unlock">Pay</span>
          </Link>
        </div>
        <nav className="flex-1 space-y-1 px-3">
          {NAV.map((item) => {
            const active = pathname === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors ${
                  active ? 'bg-ink text-white' : 'text-ink/70 hover:bg-paper'
                }`}
              >
                <NavIcon name={item.icon} />
                {item.label}
              </Link>
            );
          })}
        </nav>
        <div className="p-3">
          <button onClick={handleLogout} className="w-full rounded-lg border border-line px-3 py-2.5 text-sm font-medium text-ink/70 hover:bg-paper">
            Log out
          </button>
        </div>
      </aside>

      <div className="flex-1 pb-16 md:pb-0">
        <header className="flex items-center justify-between border-b border-line bg-white px-4 py-3 md:hidden">
          <Link href="/dashboard" className="font-display text-lg font-semibold text-ink">Off<span className="text-unlock">Pay</span></Link>
          <button onClick={handleLogout} className="text-sm text-ink/70">Log out</button>
        </header>

        <main className="mx-auto max-w-5xl px-4 py-6 md:px-8 md:py-8">{children}</main>
      </div>

      {/* Bottom tab bar — mobile only, mirrors OPay's Home/Rewards/Finance/Cards/Me */}
      <nav className="fixed inset-x-0 bottom-0 z-40 flex border-t border-line bg-white md:hidden">
        {NAV.map((item) => {
          const active = pathname === item.href;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex flex-1 flex-col items-center gap-1 py-2.5 text-[11px] font-medium ${active ? 'text-unlock' : 'text-slate'}`}
            >
              <NavIcon name={item.icon} />
              {item.label}
            </Link>
          );
        })}
      </nav>
    </div>
  );
}

function NavIcon({ name }) {
  const paths = {
    home: 'M4 11.5 12 4l8 7.5M6 10v9h12v-9',
    send: 'M4 20 20 4M20 4H9M20 4v11',
    inbox: 'M4 12h4l2 3h4l2-3h4M4 12v7h16v-7M4 12 6 5h12l2 7',
    list: 'M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01',
    file: 'M7 3h7l4 4v14H7V3Zm7 0v4h4',
    lock: 'M6 11h12v9H6v-9Zm3 0V7a3 3 0 0 1 6 0v4',
    settings: 'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6Zm7-3a7 7 0 0 1-.1 1.2l2 1.5-2 3.4-2.3-.9a7 7 0 0 1-2 1.2L14 22h-4l-.4-2.6a7 7 0 0 1-2-1.2l-2.3.9-2-3.4 2-1.5A7 7 0 0 1 5 12a7 7 0 0 1 .1-1.2l-2-1.5 2-3.4 2.3.9a7 7 0 0 1 2-1.2L10 2h4l.4 2.6a7 7 0 0 1 2 1.2l2.3-.9 2 3.4-2 1.5c.1.4.1.8.1 1.2Z',
    rewards: 'M20 7h-3.2a2.5 2.5 0 0 0-3.8-3.1L12 5l-1-1.1A2.5 2.5 0 0 0 7.2 7H4a1 1 0 0 0-1 1v3a1 1 0 0 0 1 1h16a1 1 0 0 0 1-1V8a1 1 0 0 0-1-1ZM12 7V21M20 12v7a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1v-7',
    finance: 'M4 19h16M6 19V9l4-4 4 4v10M6 19v-6h4v6',
    cards: 'M3 7a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7Zm0 4h18',
    me: 'M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8Zm-7 9a7 7 0 0 1 14 0',
  };
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
      <path d={paths[name]} stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
