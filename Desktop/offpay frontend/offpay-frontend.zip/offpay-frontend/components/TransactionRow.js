export default function TransactionRow({ txn, onDownloadReceipt }) {
  const isCredit = txn.direction === 'credit';
  return (
    <div className="flex items-center justify-between border-b border-line py-3.5 last:border-0">
      <div className="flex items-center gap-3">
        <div className={`flex h-9 w-9 items-center justify-center rounded-full text-sm font-semibold ${isCredit ? 'bg-unlock-dim text-unlock' : 'bg-lock-dim text-ink'}`}>
          {isCredit ? '↓' : '↑'}
        </div>
        <div>
          <p className="text-sm font-medium text-ink">{txn.narration || txn.type.replace(/_/g, ' ')}</p>
          <p className="text-xs text-slate">{new Date(txn.created_at).toLocaleString('en-NG')} · {txn.reference}</p>
        </div>
      </div>
      <div className="text-right">
        <p className={`font-mono text-sm font-semibold ${isCredit ? 'text-unlock' : 'text-ink'}`}>
          {isCredit ? '+' : '-'}₦{Number(txn.amount).toLocaleString()}
        </p>
        <button onClick={() => onDownloadReceipt(txn.id)} className="text-xs text-ink/60 underline underline-offset-2 hover:text-ink">
          Receipt
        </button>
      </div>
    </div>
  );
}
