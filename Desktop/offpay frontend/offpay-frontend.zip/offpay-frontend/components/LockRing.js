'use client';

/**
 * The signature visual of OffPay: a padlock-arc gauge that always shows the
 * 60/40 offline split. `mode` = 'locked' emphasizes the amber locked arc
 * (used when offline), 'unlocked' shows the full balance as available
 * (used when online, since the whole balance is spendable while connected).
 */
export default function LockRing({ balance, availablePercent = 40, mode = 'unlocked', size = 180 }) {
  const stroke = 14;
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  const availableFraction = mode === 'unlocked' ? 1 : availablePercent / 100;
  const dash = circumference * availableFraction;
  const available = mode === 'unlocked' ? balance : Math.round(balance * (availablePercent / 100));
  const locked = mode === 'unlocked' ? 0 : balance - available;

  return (
    <div className="relative inline-flex flex-col items-center">
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={radius} stroke="#FFE1AC" strokeWidth={stroke} fill="none" />
        <circle
          cx={size / 2} cy={size / 2} r={radius}
          stroke={mode === 'unlocked' ? '#1F9D74' : '#1F9D74'}
          strokeWidth={stroke}
          strokeDasharray={`${dash} ${circumference}`}
          strokeLinecap="round"
          fill="none"
          style={{ transition: 'stroke-dasharray 0.6s ease' }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <LockIcon locked={mode !== 'unlocked'} />
        <span className="mt-1 text-xs text-slate font-medium">{mode === 'unlocked' ? 'Fully available' : `${availablePercent}% available`}</span>
      </div>
      <div className="mt-4 flex gap-6 text-center">
        <div>
          <p className="text-[11px] uppercase tracking-wide text-slate">Available</p>
          <p className="font-mono text-sm font-semibold text-unlock">₦{Number(available).toLocaleString()}</p>
        </div>
        {mode !== 'unlocked' && (
          <div>
            <p className="text-[11px] uppercase tracking-wide text-slate">Locked</p>
            <p className="font-mono text-sm font-semibold text-lock">₦{Number(locked).toLocaleString()}</p>
          </div>
        )}
      </div>
    </div>
  );
}

function LockIcon({ locked }) {
  return (
    <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
      <rect x="5" y="11" width="14" height="9" rx="2" stroke="#0E2230" strokeWidth="1.6" />
      {locked ? (
        <path d="M8 11V8a4 4 0 0 1 8 0v3" stroke="#FFB020" strokeWidth="1.6" strokeLinecap="round" />
      ) : (
        <path d="M8 11V8a4 4 0 0 1 7.4-2" stroke="#1F9D74" strokeWidth="1.6" strokeLinecap="round" />
      )}
      <circle cx="12" cy="15" r="1.4" fill="#0E2230" />
    </svg>
  );
}
