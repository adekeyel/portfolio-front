'use client';
import Link from 'next/link';
import { useState } from 'react';

const LINKS = [
  { href: '/about', label: 'About' },
  { href: '/support', label: 'Support' },
  { href: '/terms', label: 'Terms' },
  { href: '/privacy', label: 'Privacy' },
];

export default function MarketingNav() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-40 border-b border-line bg-paper/90 backdrop-blur">
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
        <Link href="/" className="font-display text-xl font-semibold text-ink">
          Off<span className="text-unlock">Pay</span>
        </Link>
        <div className="hidden items-center gap-8 md:flex">
          {LINKS.map((l) => (
            <Link key={l.href} href={l.href} className="text-sm text-ink/80 hover:text-ink">
              {l.label}
            </Link>
          ))}
        </div>
        <div className="hidden items-center gap-3 md:flex">
          <Link href="/auth/login" className="text-sm font-medium text-ink hover:underline">Log in</Link>
          <Link href="/auth/register" className="rounded-lg bg-ink px-4 py-2 text-sm font-semibold text-white hover:bg-ink-700">
            Open an account
          </Link>
        </div>
        <button className="md:hidden" onClick={() => setOpen(!open)} aria-label="Toggle menu">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M4 6h16M4 12h16M4 18h16" stroke="#0E2230" strokeWidth="1.8" strokeLinecap="round"/></svg>
        </button>
      </nav>
      {open && (
        <div className="border-t border-line bg-paper px-6 py-4 md:hidden">
          {LINKS.map((l) => (
            <Link key={l.href} href={l.href} className="block py-2 text-sm text-ink">{l.label}</Link>
          ))}
          <Link href="/auth/login" className="block py-2 text-sm font-medium text-ink">Log in</Link>
          <Link href="/auth/register" className="mt-2 block rounded-lg bg-ink px-4 py-2 text-center text-sm font-semibold text-white">Open an account</Link>
        </div>
      )}
    </header>
  );
}
