/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  async rewrites() {
    // In local dev, proxy /api calls straight to the backend so you don't
    // need CORS configured for localhost. In production, NEXT_PUBLIC_API_URL
    // is used directly by lib/api.js instead.
    return [];
  },
};
module.exports = nextConfig;
