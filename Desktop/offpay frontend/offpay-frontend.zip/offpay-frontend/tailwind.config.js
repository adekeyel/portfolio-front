/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./app/**/*.{js,jsx}', './components/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        ink: {
          DEFAULT: '#0E2230',   // primary dark navy-teal — brand base
          900: '#081620',
          800: '#0E2230',
          700: '#173445',
          600: '#22495D',
        },
        paper: {
          DEFAULT: '#F3F5F4',   // cool off-white surface
          card: '#FFFFFF',
        },
        slate: {
          DEFAULT: '#5B6472',
        },
        line: '#E2E6E4',
        lock: {
          DEFAULT: '#FFB020',   // amber — the "locked / offline" signature color
          dim: '#FFE1AC',
        },
        unlock: {
          DEFAULT: '#1F9D74',   // emerald — the "available / online" signature color
          dim: '#BEE9D9',
        },
        danger: '#C0392B',
      },
      fontFamily: {
        display: ['var(--font-fraunces)', 'ui-serif', 'Georgia', 'serif'],
        body: ['var(--font-inter)', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        mono: ['var(--font-mono)', 'ui-monospace', 'SFMono-Regular', 'monospace'],
      },
      borderRadius: {
        xl2: '1.25rem',
      },
      boxShadow: {
        card: '0 1px 2px rgba(14,34,48,0.06), 0 8px 24px rgba(14,34,48,0.06)',
      },
    },
  },
  plugins: [],
};
