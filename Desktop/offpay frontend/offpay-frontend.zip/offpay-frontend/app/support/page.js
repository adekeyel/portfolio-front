'use client';
import { useEffect, useState } from 'react';
import MarketingNav from '../../components/MarketingNav';
import Footer from '../../components/Footer';
import Input from '../../components/Input';
import Button from '../../components/Button';
import Alert from '../../components/Alert';
import { apiFetch, getAccessToken } from '../../lib/api';

const FAQS = [
  { q: 'How long does account verification take?', a: 'Most accounts are reviewed within one business day. You will get an email once your BVN and passport photo have been checked and your virtual account is active.' },
  { q: 'What can I do while my account is pending verification?', a: 'You can log in and view your dashboard, but sending and receiving money is disabled until compliance approves your KYC submission.' },
  { q: 'What exactly happens to my money when I go offline?', a: '60% of your balance locks automatically and 40% stays available for wallet-to-wallet transfers to other OffPay users by Wallet ID. Nothing is deducted — it is simply held until you reconnect.' },
  { q: 'A queued offline transaction was rejected. Why?', a: 'This happens if settling it would push your offline spend past your 40% allowance — for example if you also spent from another device. Rejected transactions are never silently retried; you will see the reason on your transaction history.' },
  { q: 'How do I download a receipt or statement?', a: 'Open any transaction in your history and tap "Receipt" for a PDF, or go to the Statement page to choose a date range and download a full account statement.' },
  { q: 'My account was frozen or blocked. What do I do?', a: 'Submit a ticket below with your registered email and we will explain the reason and next steps. Frozen funds are never lost — they remain in your wallet.' },
];

export default function SupportPage() {
  const [form, setForm] = useState({ subject: '', message: '', email: '' });
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(false);
  const [loggedIn, setLoggedIn] = useState(false);
  const [ticketsRefreshKey, setTicketsRefreshKey] = useState(0);

  useEffect(() => {
    setLoggedIn(!!getAccessToken());
  }, []);

  async function submit(e) {
    e.preventDefault();
    setLoading(true);
    setStatus(null);
    try {
      await apiFetch('/support', { method: 'POST', body: { subject: form.subject, message: `${form.message}\n\n(Contact email: ${form.email})` } });
      setStatus({ type: 'success', text: 'Your message has been sent. Our support team typically replies within 24 hours.' });
      setForm({ subject: '', message: '', email: '' });
      setTicketsRefreshKey((k) => k + 1);
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div>
      <MarketingNav />
      <section className="mx-auto max-w-3xl px-6 py-20">
        <p className="text-xs font-semibold uppercase tracking-wide text-unlock">Support</p>
        <h1 className="mt-3 font-display text-4xl text-ink">We're here to help.</h1>
        <p className="mt-4 text-slate">Browse common questions below, or send our support team a message directly.</p>

        <div className="mt-12 space-y-4">
          {FAQS.map((f) => (
            <details key={f.q} className="rounded-xl2 border border-line bg-white p-5 shadow-card [&_summary]:cursor-pointer">
              <summary className="font-display text-base text-ink">{f.q}</summary>
              <p className="mt-3 text-sm text-slate">{f.a}</p>
            </details>
          ))}
        </div>

        <div className="mt-16 rounded-xl2 border border-line bg-white p-8 shadow-card">
          <h2 className="font-display text-2xl text-ink">Contact support</h2>
          <form onSubmit={submit} className="mt-6 space-y-4">
            <Input label="Your email" type="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
            <Input label="Subject" required value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} />
            <label className="block">
              <span className="mb-1.5 block text-sm font-medium text-ink">Message</span>
              <textarea
                required rows={5} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })}
                className="w-full rounded-lg border border-line bg-white px-3.5 py-2.5 text-sm text-ink focus:border-unlock"
              />
            </label>
            {status && <Alert type={status.type}>{status.text}</Alert>}
            <Button type="submit" disabled={loading}>{loading ? 'Sending…' : 'Send message'}</Button>
          </form>
          <p className="mt-4 text-xs text-slate">Or email us directly at support@offpay.app</p>
        </div>

        {loggedIn && <MyTickets refreshKey={ticketsRefreshKey} />}
      </section>
      <Footer />
    </div>
  );
}

/** Lists the logged-in user's own tickets and lets them open a thread to read admin replies and reply back. */
function MyTickets({ refreshKey }) {
  const [tickets, setTickets] = useState([]);
  const [error, setError] = useState(null);
  const [openId, setOpenId] = useState(null);
  const [thread, setThread] = useState(null);
  const [replyText, setReplyText] = useState('');
  const [replying, setReplying] = useState(false);

  useEffect(() => { load(); }, [refreshKey]);

  // Light polling so a reply the support team sends shows up without the
  // user needing to know to refresh the page.
  useEffect(() => {
    const timer = setInterval(load, 20000);
    return () => clearInterval(timer);
  }, []);

  async function load() {
    try {
      const res = await apiFetch('/support/mine');
      setTickets(res.data);
    } catch (err) {
      setError(err.message);
    }
  }

  async function openTicket(id) {
    setOpenId(id);
    setThread(null);
    try {
      const res = await apiFetch(`/support/${id}`);
      setThread(res.data);
    } catch (err) {
      setError(err.message);
    }
  }

  async function sendReply(id) {
    if (!replyText.trim()) return;
    setReplying(true);
    try {
      await apiFetch(`/support/${id}/reply`, { method: 'POST', body: { message: replyText } });
      setReplyText('');
      await openTicket(id);
      await load();
    } catch (err) {
      setError(err.message);
    } finally {
      setReplying(false);
    }
  }

  const STATUS_LABEL = { open: 'Open', in_progress: 'In progress', resolved: 'Resolved', closed: 'Closed' };

  return (
    <div className="mt-10 rounded-xl2 border border-line bg-white p-8 shadow-card">
      <h2 className="font-display text-2xl text-ink">My tickets</h2>
      <p className="mt-1 text-sm text-slate">Messages you've sent us, and any replies from the support team.</p>
      {error && <div className="mt-4"><Alert type="error">{error}</Alert></div>}

      <div className="mt-6 space-y-3">
        {tickets.map((t) => (
          <div key={t.id} className="rounded-xl2 border border-line">
            <button
              onClick={() => openTicket(openId === t.id ? null : t.id)}
              className="flex w-full items-center justify-between gap-3 px-5 py-4 text-left"
            >
              <div>
                <p className="text-sm font-medium text-ink">{t.subject}</p>
                {t.last_reply_message && (
                  <p className="mt-0.5 line-clamp-1 text-xs text-slate">
                    {t.last_reply_author_type === 'admin' ? 'Support: ' : 'You: '}{t.last_reply_message}
                  </p>
                )}
              </div>
              <span className="shrink-0 rounded-full bg-paper px-2.5 py-0.5 text-xs font-medium capitalize">{STATUS_LABEL[t.status] || t.status}</span>
            </button>

            {openId === t.id && (
              <div className="border-t border-line px-5 py-4">
                {!thread ? (
                  <p className="text-sm text-slate">Loading…</p>
                ) : (
                  <>
                    <div className="space-y-3">
                      <div className="rounded-lg bg-paper p-3 text-sm text-ink">{thread.ticket.message}</div>
                      {thread.replies.map((r) => (
                        <div
                          key={r.id}
                          className={`rounded-lg p-3 text-sm ${r.author_type === 'admin' ? 'bg-unlock-dim text-ink' : 'bg-paper text-ink'}`}
                        >
                          <p className="mb-1 text-xs font-medium text-slate">{r.author_type === 'admin' ? 'Support team' : 'You'}</p>
                          {r.message}
                        </div>
                      ))}
                    </div>
                    {thread.ticket.status !== 'closed' && (
                      <div className="mt-4 space-y-2">
                        <textarea
                          value={replyText} onChange={(e) => setReplyText(e.target.value)}
                          placeholder="Write a reply…" rows={2}
                          className="w-full rounded-lg border border-line px-3 py-2 text-sm"
                        />
                        <Button variant="ghost" onClick={() => sendReply(t.id)} disabled={replying}>
                          {replying ? 'Sending…' : 'Send reply'}
                        </Button>
                      </div>
                    )}
                  </>
                )}
              </div>
            )}
          </div>
        ))}
        {tickets.length === 0 && <p className="text-sm text-slate">No tickets yet — send us a message above.</p>}
      </div>
    </div>
  );
}
