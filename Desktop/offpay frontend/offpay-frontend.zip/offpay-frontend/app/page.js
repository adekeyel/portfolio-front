import MarketingNav from '../components/MarketingNav';
import Footer from '../components/Footer';
import LockRing from '../components/LockRing';
import DeviceGate from '../components/DeviceGate';
import AdSlot from '../components/AdSlot';
import Link from 'next/link';

export default function HomePage() {
  return (
    <div>
      <DeviceGate />
      <MarketingNav />

      {/* Hero — the thesis: money you can still spend, safely, when the network can't reach you */}
      <section className="mx-auto grid max-w-6xl items-center gap-12 px-6 py-20 md:grid-cols-2 md:py-28">
        <div>
          <p className="mb-4 inline-block rounded-full border border-line bg-white px-3 py-1 text-xs font-medium text-slate">
            Licensed digital wallet · Nigeria
          </p>
          <h1 className="font-display text-4xl leading-tight text-ink md:text-5xl">
            Money that moves, <em className="italic text-unlock">even offline.</em>
          </h1>
          <p className="mt-5 max-w-md text-base text-slate">
            Send and receive from any Nigerian or international bank, pay other OffPay
            users instantly, and keep a protected 40% of your balance spendable
            the moment your connection drops.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link href="/auth/register" className="rounded-lg bg-ink px-6 py-3 text-sm font-semibold text-white hover:bg-ink-700">
              Open a free account
            </Link>
            <Link href="/about" className="rounded-lg border border-line bg-white px-6 py-3 text-sm font-semibold text-ink hover:bg-paper">
              How it works
            </Link>
          </div>
          <div className="mt-10 flex gap-8">
            <div>
              <p className="font-display text-2xl text-ink">60/40</p>
              <p className="text-xs text-slate">offline lock ratio</p>
            </div>
            <div>
              <p className="font-display text-2xl text-ink">2</p>
              <p className="text-xs text-slate">settlement providers, auto-failover</p>
            </div>
            <div>
              <p className="font-display text-2xl text-ink">₦10</p>
              <p className="text-xs text-slate">flat wallet-to-wallet fee</p>
            </div>
          </div>
        </div>

        <div className="flex justify-center">
          <div className="rounded-xl2 border border-line bg-white p-8 shadow-card">
            <p className="mb-1 text-xs uppercase tracking-wide text-slate">Wallet balance</p>
            <p className="font-mono text-3xl font-semibold text-ink">₦248,500.00</p>
            <div className="mt-6 flex justify-center">
              <LockRing balance={248500} availablePercent={40} mode="locked" />
            </div>
            <p className="mt-4 text-center text-xs text-slate">
              This is what your dashboard shows the instant you go offline —
              nothing hidden, nothing frozen without explanation.
            </p>
          </div>
        </div>
      </section>

      <div className="py-6"><AdSlot page="landing" slot="middle" /></div>

      {/* How the offline lock works — the signature mechanic explained */}
      <section className="border-y border-line bg-white py-20">
        <div className="mx-auto max-w-6xl px-6">
          <h2 className="font-display text-3xl text-ink">How the offline lock protects you</h2>
          <p className="mt-3 max-w-2xl text-slate">
            Every wallet carries an always-on safeguard. It doesn't ask you to configure anything —
            it just quietly recalculates the moment your connection changes.
          </p>
          <div className="mt-12 grid gap-8 md:grid-cols-3">
            <FeatureStep
              title="While you're connected"
              body="Your full balance is available for transfers to banks, other OffPay wallets, or offline wallets — no cap applied."
              color="unlock"
            />
            <FeatureStep
              title="The moment you disconnect"
              body="60% of your balance locks automatically. The remaining 40% stays spendable for wallet-to-wallet payments by Wallet ID."
              color="lock"
            />
            <FeatureStep
              title="When you reconnect"
              body="Queued offline payments settle against your real balance, and the full amount unlocks again — verified, never assumed."
              color="unlock"
            />
          </div>
        </div>
      </section>

      {/* What you can do */}
      <section className="mx-auto max-w-6xl px-6 py-20">
        <h2 className="font-display text-3xl text-ink">Everything a modern wallet should do</h2>
        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {[
            { t: 'Bank transfers', d: 'Send and receive from any commercial bank in Nigeria, with international routes coming online as we scale.' },
            { t: 'OffPay-to-OffPay', d: 'Pay another user instantly by Wallet ID or account number — ₦10 flat, no surprises.' },
            { t: 'Offline payments', d: 'Keep transacting with other users even without a connection, inside your protected 40% limit.' },
            { t: 'Bank-grade verification', d: 'BVN and passport verification reviewed by our compliance team before your virtual account activates.' },
            { t: 'Receipts & statements', d: 'Download a PDF receipt after every transaction, or a full statement for any date range.' },
            { t: 'Dual-provider reliability', d: 'Payments route through Flutterwave and Paystack with automatic failover, so a single outage never stops you.' },
          ].map((f) => (
            <div key={f.t} className="rounded-xl2 border border-line bg-white p-6 shadow-card">
              <h3 className="font-display text-lg text-ink">{f.t}</h3>
              <p className="mt-2 text-sm text-slate">{f.d}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-ink py-20">
        <div className="mx-auto max-w-4xl px-6 text-center">
          <h2 className="font-display text-3xl text-white">Open your OffPay wallet in minutes.</h2>
          <p className="mt-3 text-white/70">Verification usually clears within one business day.</p>
          <Link href="/auth/register" className="mt-8 inline-block rounded-lg bg-white px-7 py-3 text-sm font-semibold text-ink hover:bg-paper">
            Get started
          </Link>
        </div>
      </section>

      <Footer />
    </div>
  );
}

function FeatureStep({ title, body, color }) {
  const dot = color === 'unlock' ? 'bg-unlock' : 'bg-lock';
  return (
    <div>
      <span className={`inline-block h-2.5 w-2.5 rounded-full ${dot}`} />
      <h3 className="mt-3 font-display text-lg text-ink">{title}</h3>
      <p className="mt-2 text-sm text-slate">{body}</p>
    </div>
  );
}
