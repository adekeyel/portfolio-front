import MarketingNav from '../../components/MarketingNav';
import Footer from '../../components/Footer';

export const metadata = { title: 'About — OffPay' };

export default function AboutPage() {
  return (
    <div>
      <MarketingNav />
      <section className="mx-auto max-w-3xl px-6 py-20">
        <p className="text-xs font-semibold uppercase tracking-wide text-unlock">About us</p>
        <h1 className="mt-3 font-display text-4xl text-ink">Built for how Nigerians actually move money.</h1>
        <p className="mt-6 text-slate">
          OffPay Technologies Ltd was founded on a simple observation: money doesn't stop
          needing to move just because a network signal does. Across Nigeria, connectivity
          drops for minutes or hours at a time — in transit, in rural areas, during
          network congestion — and every one of those moments is a missed transaction,
          a stalled business, an inconvenienced customer.
        </p>
        <p className="mt-4 text-slate">
          We built OffPay to close that gap responsibly. Rather than pretending true
          offline-to-offline transfers are possible without any connectivity anywhere in
          the chain — which would open the door to double-spending and fraud — we designed
          a protected offline allowance: 40% of your balance stays spendable to other
          OffPay users the instant your connection drops, while the remaining 60% stays
          locked and verified until you're back online. It's a small trade-off that keeps
          your money safe without leaving you stranded.
        </p>

        <h2 className="mt-12 font-display text-2xl text-ink">What we do</h2>
        <ul className="mt-4 list-disc space-y-2 pl-5 text-slate">
          <li>Issue verified digital wallets with dedicated virtual bank accounts.</li>
          <li>Route bank transfers through multiple licensed payment processors for reliability.</li>
          <li>Provide instant wallet-to-wallet payments between OffPay users.</li>
          <li>Maintain a protected offline balance so connectivity gaps don't stop commerce.</li>
          <li>Give every user downloadable receipts and statements for full transparency.</li>
        </ul>

        <h2 className="mt-12 font-display text-2xl text-ink">How we operate</h2>
        <p className="mt-4 text-slate">
          Every account is verified against Bank Verification Number (BVN) records and a
          government-issued passport photograph before it can send or receive money. Our
          compliance team reviews each submission individually — we don't auto-approve
          identity documents. Funds move through Flutterwave and Paystack, two of Nigeria's
          licensed payment service providers, with automatic failover between them so a
          single provider's downtime never stops your transaction.
        </p>

        <h2 className="mt-12 font-display text-2xl text-ink">Our commitment</h2>
        <p className="mt-4 text-slate">
          We publish our fees plainly, we explain every deduction on your statement, and
          we never lock funds without telling you why. If something about your account
          changes — a freeze, a block, a suspension — you'll always be able to reach our
          support team for a clear explanation and a path to resolution.
        </p>
      </section>
      <Footer />
    </div>
  );
}
