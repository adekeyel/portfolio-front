import MarketingNav from '../../components/MarketingNav';
import Footer from '../../components/Footer';

export const metadata = { title: 'Privacy Policy — OffPay' };

export default function PrivacyPage() {
  return (
    <div>
      <MarketingNav />
      <section className="mx-auto max-w-3xl px-6 py-20">
        <p className="text-xs font-semibold uppercase tracking-wide text-unlock">Legal</p>
        <h1 className="mt-3 font-display text-4xl text-ink">Privacy Policy</h1>
        <p className="mt-3 text-sm text-slate">Last updated: July 2026 · This is a starting template — have qualified Nigerian data protection counsel (NDPA-compliant) review it before launch.</p>

        <div className="mt-10 space-y-8 text-slate">
          <T title="1. Information we collect">
            To open and operate your wallet, we collect: your full legal name, email
            address, phone number, Bank Verification Number (BVN), passport photograph,
            date of birth (where provided), device identifiers, transaction history, and
            IP address at login. We do not collect more identity information than is
            required for regulatory Know-Your-Customer (KYC) compliance.
          </T>

          <T title="2. How we use your information">
            We use your information to: verify your identity before activating your
            wallet; generate and maintain your dedicated virtual bank account; process
            transactions and calculate applicable fees; detect and prevent fraud; comply
            with Nigerian financial regulations (including reporting obligations to the
            Central Bank of Nigeria and other authorities where legally required); and
            communicate with you about your account, including security alerts and OTPs.
          </T>

          <T title="3. Who we share information with">
            We share the minimum necessary information with: our licensed payment
            processing partners (Flutterwave and Paystack) to move money on your behalf;
            regulators and law enforcement where legally compelled; and our email/SMS
            delivery providers, solely to deliver OTPs and account notifications. We do
            not sell your personal information to third parties, and we do not share your
            BVN or passport photograph with anyone outside of identity verification and
            regulatory purposes.
          </T>

          <T title="4. Data storage and security">
            Your data is stored in an access-controlled PostgreSQL database. Passwords
            and transaction PINs are stored as salted cryptographic hashes and are never
            stored or transmitted in plain text. Your BVN is masked in the app interface
            after verification is complete. Access to identity documents is restricted to
            our compliance team. We use encryption in transit (HTTPS/TLS) for all traffic
            between your device and our servers.
          </T>

          <T title="5. Your rights">
            You may request a copy of the personal data we hold about you, request
            correction of inaccurate data, or request account closure, subject to our
            obligation to retain certain financial records for the period required by
            Nigerian law (typically a minimum of five years after account closure for
            AML/CFT purposes). Requests can be made through the in-app Support page or by
            emailing privacy@offpay.app.
          </T>

          <T title="6. Data retention">
            We retain transaction records, KYC documents, and account activity logs for
            as long as your account is active and for the statutory retention period
            thereafter required by Nigerian financial regulations. Data no longer subject
            to a retention requirement is securely deleted.
          </T>

          <T title="7. Offline mode and local storage">
            When you use offline mode, a limited amount of data — your offline spending
            token, wallet ID, and queued transaction details — is stored temporarily on
            your device to allow transactions to be authorized without a live connection.
            This data is cleared once your queued transactions are synced with our
            servers, and never contains your password, PIN, or full BVN.
          </T>

          <T title="8. Children's privacy">
            OffPay is not directed at, and does not knowingly collect information from,
            anyone under 18 years of age, consistent with our BVN-based eligibility
            requirement.
          </T>

          <T title="9. Changes to this policy">
            We may update this Privacy Policy from time to time. Material changes will be
            communicated in-app or by email before they take effect.
          </T>

          <T title="10. Contact">
            Questions or requests regarding your personal data can be sent to
            privacy@offpay.app or through the in-app Support page.
          </T>
        </div>
      </section>
      <Footer />
    </div>
  );
}

function T({ title, children }) {
  return (
    <div>
      <h2 className="font-display text-xl text-ink">{title}</h2>
      <p className="mt-2 text-sm leading-relaxed">{children}</p>
    </div>
  );
}
