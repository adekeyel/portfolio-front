import MarketingNav from '../../components/MarketingNav';
import Footer from '../../components/Footer';

export const metadata = { title: 'Terms of Service — OffPay' };

export default function TermsPage() {
  return (
    <div>
      <MarketingNav />
      <section className="mx-auto max-w-3xl px-6 py-20">
        <p className="text-xs font-semibold uppercase tracking-wide text-unlock">Legal</p>
        <h1 className="mt-3 font-display text-4xl text-ink">Terms of Service</h1>
        <p className="mt-3 text-sm text-slate">Last updated: July 2026 · This is a starting template — have qualified Nigerian fintech counsel review it before launch.</p>

        <div className="mt-10 space-y-8 text-slate">
          <T n="1" title="Acceptance of these Terms">
            By creating a OffPay account, you agree to be bound by these Terms of Service
            and our Privacy Policy. If you do not agree, do not register for or use the
            OffPay app. These Terms form a binding agreement between you and OffPay
            Technologies Ltd ("OffPay", "we", "us").
          </T>

          <T n="2" title="Eligibility and account verification">
            You must be at least 18 years old and a holder of a valid Bank Verification
            Number (BVN) to open a OffPay wallet. You agree to provide your full legal
            name exactly as it appears on your BVN record, a valid phone number, email
            address, and a clear passport photograph. Your account remains in
            "pending verification" status — unable to send or receive funds — until our
            compliance team reviews and approves your submission. We may request
            additional documentation at any time and may decline to approve an account
            at our sole discretion.
          </T>

          <T n="3" title="Your wallet and virtual account">
            Once approved, OffPay issues you a dedicated virtual bank account number
            through one of our licensed payment partners (Flutterwave or Paystack). This
            virtual account allows you to receive transfers from any Nigerian bank
            directly into your OffPay wallet. You are responsible for keeping your
            login credentials, transaction PIN, and One-Time Passwords (OTPs)
            confidential. OffPay staff will never ask you for your password, PIN, or OTP.
          </T>

          <T n="4" title="The offline spending allowance">
            OffPay wallets include a protected offline mode. While your device has an
            active internet connection, your full balance is available for transfers.
            The moment your device loses connectivity, OffPay automatically locks 60%
            of your wallet balance and makes the remaining 40% available for
            wallet-to-wallet transfers to other OffPay users by Wallet ID. Offline
            transactions are queued on your device and settled against your actual
            balance once connectivity is restored. If a queued transaction would exceed
            your available offline allowance at the time of settlement — for example,
            because of activity from another device — OffPay will reject that specific
            transaction and notify you, rather than allow your wallet to go negative.
            This mechanism exists to protect you and other users from fraud and
            double-spending; it is not adjustable by the user.
          </T>

          <T n="5" title="Fees">
            OffPay charges the following standard fees, which may be updated from time
            to time with notice provided in-app: ₦10 on deposits from other banks below
            ₦1,000, and a flat ₦50 on deposits of ₦1,000 or more; ₦20 flat on interbank
            transfers below ₦10,000, and ₦60 flat on interbank transfers of ₦10,000 or
            more; ₦10 flat on intra-bank transfers and on wallet-to-wallet transfers
            (including offline transfers). Fees are deducted automatically at the time
            of the transaction and shown on your receipt and statement.
          </T>

          <T n="6" title="Prohibited use">
            You agree not to use OffPay for money laundering, terrorism financing, fraud,
            or any illegal purpose; not to attempt to circumvent identity verification;
            not to use another person's identity documents; and not to attempt to exploit,
            reverse-engineer, or interfere with the offline lock mechanism or any other
            security control. Violation of this section may result in immediate account
            suspension and reporting to relevant regulatory or law enforcement authorities.
          </T>

          <T n="7" title="Account actions: blocking, freezing, suspension, and closure">
            OffPay may block, freeze, suspend, or close your account where we reasonably
            suspect fraud, a breach of these Terms, a legal or regulatory requirement, or
            unusual account activity. Where possible, we will notify you of the action
            taken and the reason. A frozen wallet retains its balance but cannot send or
            receive funds until unfrozen. You may contact support to appeal any account
            action.
          </T>

          <T n="8" title="Transaction reversals">
            OffPay may reverse a transaction where it was made in error, where fraud is
            confirmed, or where required by a payment partner or regulator. Reversals are
            recorded transparently on your transaction history and statement.
          </T>

          <T n="9" title="Liability">
            OffPay is not liable for losses arising from your failure to keep your
            credentials secure, from providing incorrect recipient details, or from
            circumstances beyond our reasonable control (including outages at our
            payment partners, telecommunications providers, or banking infrastructure).
            Nothing in these Terms limits liability that cannot be excluded under
            applicable Nigerian law.
          </T>

          <T n="10" title="Changes to these Terms">
            We may update these Terms from time to time. Material changes will be
            communicated in-app or by email before they take effect. Continued use of
            OffPay after changes take effect constitutes acceptance of the revised Terms.
          </T>

          <T n="11" title="Governing law">
            These Terms are governed by the laws of the Federal Republic of Nigeria.
          </T>

          <T n="12" title="Contact">
            Questions about these Terms can be sent to legal@offpay.app or through the
            in-app Support page.
          </T>
        </div>
      </section>
      <Footer />
    </div>
  );
}

function T({ n, title, children }) {
  return (
    <div>
      <h2 className="font-display text-xl text-ink">{n}. {title}</h2>
      <p className="mt-2 text-sm leading-relaxed">{children}</p>
    </div>
  );
}
