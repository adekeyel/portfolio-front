'use client';
import { useState } from 'react';
import DashboardShell from '../../../components/DashboardShell';
import Input from '../../../components/Input';
import Button from '../../../components/Button';
import Alert from '../../../components/Alert';
import { downloadFile } from '../../../lib/api';

export default function StatementPage() {
  const today = new Date().toISOString().slice(0, 10);
  const monthAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);
  const [range, setRange] = useState({ from: monthAgo, to: today });
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(false);

  async function download(e) {
    e.preventDefault();
    setStatus(null);
    setLoading(true);
    try {
      await downloadFile(`/transactions/statement/download?from=${range.from}&to=${range.to}`, `OffPay-Statement-${range.from}-to-${range.to}.pdf`);
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    } finally {
      setLoading(false);
    }
  }

  return (
    <DashboardShell>
      <h1 className="font-display text-2xl text-ink">Account statement</h1>
      <p className="mt-1 text-sm text-slate">Download a PDF statement for any date range.</p>

      <form onSubmit={download} className="mt-8 max-w-md space-y-4 rounded-xl2 border border-line bg-white p-6 shadow-card">
        <Input label="From" type="date" required value={range.from} onChange={(e) => setRange({ ...range, from: e.target.value })} />
        <Input label="To" type="date" required value={range.to} onChange={(e) => setRange({ ...range, to: e.target.value })} />
        {status && <Alert type={status.type}>{status.text}</Alert>}
        <Button type="submit" className="w-full" disabled={loading}>{loading ? 'Preparing…' : 'Download statement'}</Button>
      </form>
    </DashboardShell>
  );
}
