'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import DashboardShell from '../../../../components/DashboardShell';
import Alert from '../../../../components/Alert';
import Button from '../../../../components/Button';
import Input from '../../../../components/Input';
import Toggle from '../../../../components/Toggle';
import { apiFetch } from '../../../../lib/api';

export default function SecuritySettingsPage() {
  const [settings, setSettings] = useState(null);
  const [status, setStatus] = useState(null);
  const [busyKey, setBusyKey] = useState(null);
  const [google2faModal, setGoogle2faModal] = useState(false);
  const [passcodeModal, setPasscodeModal] = useState(false);

  useEffect(() => { load(); }, []);

  function load() {
    apiFetch('/security').then((res) => setSettings(res.data)).catch((err) => setStatus({ type: 'error', text: err.message }));
  }

  async function toggle(key, endpoint, enabled) {
    setStatus(null);
    setBusyKey(key);
    try {
      await apiFetch(endpoint, { method: 'POST', body: { enabled } });
      setSettings((s) => ({ ...s, [key]: enabled }));
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    } finally {
      setBusyKey(null);
    }
  }

  if (!settings) {
    return (
      <DashboardShell>
        <h1 className="font-display text-2xl text-ink">Security Settings</h1>
        {status && <div className="mt-4"><Alert type={status.type}>{status.text}</Alert></div>}
      </DashboardShell>
    );
  }

  return (
    <DashboardShell>
      <div className="flex items-center gap-3">
        <Link href="/dashboard/settings" className="text-ink/60 hover:text-ink">←</Link>
        <h1 className="font-display text-2xl text-ink">Security Settings</h1>
      </div>

      <div className="mt-4 max-w-lg rounded-xl2 border border-lock/40 bg-lock-dim p-4 text-sm text-ink">
        Keep at least one verification method on for withdrawals — it's what protects your funds if your password or device is ever compromised.
      </div>

      {status && <div className="mt-4 max-w-lg"><Alert type={status.type}>{status.text}</Alert></div>}

      <div className="mt-6 max-w-lg space-y-1 rounded-xl2 border border-line bg-white shadow-card">
        <SettingRow
          title="Transfer Protection"
          description="Add an extra layer of security to fund transfers by requiring verification before completion."
          checked={settings.transfer_protection_enabled}
          busy={busyKey === 'transfer_protection_enabled'}
          onChange={(v) => toggle('transfer_protection_enabled', '/security/transfer-protection', v)}
        />
        <SettingRow
          title="Enable Biometrics"
          description="Approve logins & transactions using Face ID or fingerprint on this device."
          checked={settings.biometrics_enabled}
          busy={busyKey === 'biometrics_enabled'}
          onChange={(v) => toggle('biometrics_enabled', '/security/biometrics', v)}
        />
        <SettingRow
          title="Enable Google 2FA for Withdrawals"
          description="All transactions will require a Google Authenticator code generated on your device to verify your identity."
          checked={settings.google2fa_enabled}
          busy={busyKey === 'google2fa_enabled'}
          onChange={(v) => {
            if (v) setGoogle2faModal(true);
            else disableGoogle2fa();
          }}
        />
        <SettingRow
          title="Enable Email 2FA for Withdrawals"
          description="All transactions will require an Email OTP code to verify your identity."
          checked={settings.email2fa_withdrawals_enabled}
          busy={busyKey === 'email2fa_withdrawals_enabled'}
          onChange={(v) => toggle('email2fa_withdrawals_enabled', '/security/email-2fa', v)}
        />
        <button onClick={() => setPasscodeModal(true)} className="flex w-full items-center justify-between px-5 py-4 text-left hover:bg-paper">
          <div>
            <p className="font-medium text-ink">Passcode</p>
            <p className="mt-0.5 text-sm text-slate">Change your passcode</p>
          </div>
          <span className="text-slate">›</span>
        </button>
      </div>

      {google2faModal && (
        <Google2faModal
          onClose={() => setGoogle2faModal(false)}
          onEnabled={() => { setSettings((s) => ({ ...s, google2fa_enabled: true })); setGoogle2faModal(false); }}
        />
      )}
      {passcodeModal && <PasscodeModal onClose={() => setPasscodeModal(false)} />}
    </DashboardShell>
  );

  async function disableGoogle2fa() {
    setStatus(null);
    setBusyKey('google2fa_enabled');
    try {
      await apiFetch('/security/google-2fa/disable', { method: 'POST' });
      setSettings((s) => ({ ...s, google2fa_enabled: false }));
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    } finally {
      setBusyKey(null);
    }
  }
}

function SettingRow({ title, description, checked, busy, onChange }) {
  return (
    <div className="flex items-start justify-between gap-4 border-b border-line px-5 py-4 last:border-b-0">
      <div>
        <p className="font-medium text-ink">{title}</p>
        <p className="mt-0.5 text-sm text-slate">{description}</p>
      </div>
      <Toggle checked={!!checked} disabled={busy} onChange={onChange} />
    </div>
  );
}

/** Step 1: fetch a fresh secret + QR from /security/google-2fa/start. Step 2: confirm the 6-digit code to actually turn it on. */
function Google2faModal({ onClose, onEnabled }) {
  const [setup, setSetup] = useState(null);
  const [code, setCode] = useState('');
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    apiFetch('/security/google-2fa/start', { method: 'POST' }).then((res) => setSetup(res.data)).catch((err) => setStatus({ type: 'error', text: err.message }));
  }, []);

  async function confirm(e) {
    e.preventDefault();
    setStatus(null);
    setLoading(true);
    try {
      await apiFetch('/security/google-2fa/confirm', { method: 'POST', body: { code } });
      onEnabled();
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink/40 px-4">
      <div className="w-full max-w-sm rounded-xl2 bg-white p-6 shadow-card">
        <h2 className="font-display text-lg text-ink">Set up Google 2FA</h2>
        <p className="mt-1 text-sm text-slate">Scan this with Google Authenticator (or any TOTP app), then enter the 6-digit code it shows.</p>

        {setup ? (
          <>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={setup.qrDataUrl} alt="Google 2FA QR code" className="mx-auto mt-4 h-40 w-40" />
            <p className="mt-2 break-all rounded-lg bg-paper px-3 py-2 text-center font-mono text-xs text-slate">{setup.secret}</p>
            <form onSubmit={confirm} className="mt-4 space-y-3">
              <Input label="6-digit code" maxLength={6} value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))} required />
              {status && <Alert type={status.type}>{status.text}</Alert>}
              <div className="flex gap-2">
                <Button type="submit" disabled={loading} className="flex-1">{loading ? 'Confirming…' : 'Confirm & enable'}</Button>
                <Button type="button" variant="ghost" onClick={onClose}>Cancel</Button>
              </div>
            </form>
          </>
        ) : (
          !status && <p className="mt-4 text-sm text-slate">Generating your secret…</p>
        )}
        {!setup && status && <div className="mt-4"><Alert type={status.type}>{status.text}</Alert></div>}
      </div>
    </div>
  );
}

/** Reuses the existing app-lock PIN endpoint — same PIN used to unlock the app itself. */
function PasscodeModal({ onClose }) {
  const [form, setForm] = useState({ pin: '', confirmPin: '' });
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setStatus(null);
    if (form.pin !== form.confirmPin) return setStatus({ type: 'error', text: 'Passcodes do not match.' });
    setLoading(true);
    try {
      await apiFetch('/auth/set-app-lock-pin', { method: 'POST', body: { pin: form.pin } });
      setStatus({ type: 'success', text: 'Passcode updated.' });
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink/40 px-4">
      <div className="w-full max-w-sm rounded-xl2 bg-white p-6 shadow-card">
        <h2 className="font-display text-lg text-ink">Change passcode</h2>
        <p className="mt-1 text-sm text-slate">This 4-digit passcode unlocks the app on this device.</p>
        <form onSubmit={submit} className="mt-4 space-y-3">
          <Input label="New passcode" type="password" maxLength={4} required value={form.pin} onChange={(e) => setForm({ ...form, pin: e.target.value.replace(/\D/g, '') })} />
          <Input label="Confirm passcode" type="password" maxLength={4} required value={form.confirmPin} onChange={(e) => setForm({ ...form, confirmPin: e.target.value.replace(/\D/g, '') })} />
          {status && <Alert type={status.type}>{status.text}</Alert>}
          <div className="flex gap-2">
            <Button type="submit" disabled={loading} className="flex-1">{loading ? 'Saving…' : 'Save passcode'}</Button>
            <Button type="button" variant="ghost" onClick={onClose}>Close</Button>
          </div>
        </form>
      </div>
    </div>
  );
}
