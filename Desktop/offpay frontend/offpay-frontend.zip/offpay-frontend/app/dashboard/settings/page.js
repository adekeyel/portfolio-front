'use client';
import { useEffect, useState } from 'react';
import DashboardShell from '../../../components/DashboardShell';
import Input from '../../../components/Input';
import Button from '../../../components/Button';
import Alert from '../../../components/Alert';
import Link from 'next/link';
import { apiFetch } from '../../../lib/api';

export default function SettingsPage() {
  const [profile, setProfile] = useState(null);

  function loadProfile() {
    apiFetch('/users/me').then((res) => setProfile(res.data)).catch(() => {});
  }

  useEffect(() => { loadProfile(); }, []);

  return (
    <DashboardShell>
      <h1 className="font-display text-2xl text-ink">Settings</h1>

      {profile && (
        <div className="mt-6 max-w-lg rounded-xl2 border border-line bg-white p-6 shadow-card">
          <h2 className="font-display text-lg text-ink">Profile</h2>
          <dl className="mt-3 space-y-2 text-sm">
            <Row label="Full name" value={profile.full_name} />
            <Row label="Email" value={profile.email} />
            <Row label="Phone" value={profile.phone} />
            <Row label="BVN" value={profile.bvn} />
            <Row label="KYC status" value={profile.kyc_status} />
            <Row label="Verification tier" value={`Tier ${profile.kyc_tier}`} />
            {profile.tier_upgrade_status === 'pending' && <Row label="Tier upgrade" value="Pending review" />}
          </dl>
        </div>
      )}

      {profile && profile.kyc_status === 'approved' && profile.kyc_tier < 3 && profile.tier_upgrade_status !== 'pending' && (
        <div className="mt-8 max-w-lg">
          <TierUpgradeForm profile={profile} onSubmitted={loadProfile} />
        </div>
      )}

      <div className="mt-8 max-w-lg">
        <Link href="/dashboard/settings/security" className="flex items-center justify-between rounded-xl2 border border-line bg-white p-6 shadow-card hover:bg-paper">
          <div>
            <h2 className="font-display text-lg text-ink">Security Settings</h2>
            <p className="mt-1 text-sm text-slate">Transfer protection, biometrics, 2FA, and passcode.</p>
          </div>
          <span className="text-slate">›</span>
        </Link>
      </div>

      <div className="mt-8 max-w-lg">
        <PinForm />
      </div>
      <div className="mt-8 max-w-lg">
        <PasswordForm />
      </div>
    </DashboardShell>
  );
}

function Row({ label, value }) {
  return (
    <div className="flex justify-between border-b border-line pb-2">
      <dt className="text-slate">{label}</dt>
      <dd className="font-medium text-ink">{value}</dd>
    </div>
  );
}

function PinForm() {
  const [form, setForm] = useState({ pin: '', currentPassword: '' });
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setStatus(null);
    setLoading(true);
    try {
      await apiFetch('/users/pin', { method: 'POST', body: form });
      setStatus({ type: 'success', text: 'Transaction PIN updated.' });
      setForm({ pin: '', currentPassword: '' });
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={submit} className="space-y-4 rounded-xl2 border border-line bg-white p-6 shadow-card">
      <h2 className="font-display text-lg text-ink">Transaction PIN</h2>
      <Input label="New 4-digit PIN" type="password" maxLength={4} required value={form.pin} onChange={(e) => setForm({ ...form, pin: e.target.value.replace(/\D/g, '') })} />
      <Input label="Confirm your password" type="password" required value={form.currentPassword} onChange={(e) => setForm({ ...form, currentPassword: e.target.value })} />
      {status && <Alert type={status.type}>{status.text}</Alert>}
      <Button type="submit" disabled={loading}>{loading ? 'Saving…' : 'Update PIN'}</Button>
    </form>
  );
}

function PasswordForm() {
  const [form, setForm] = useState({ currentPassword: '', newPassword: '' });
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setStatus(null);
    setLoading(true);
    try {
      await apiFetch('/users/change-password', { method: 'POST', body: form });
      setStatus({ type: 'success', text: 'Password updated.' });
      setForm({ currentPassword: '', newPassword: '' });
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={submit} className="space-y-4 rounded-xl2 border border-line bg-white p-6 shadow-card">
      <h2 className="font-display text-lg text-ink">Password</h2>
      <Input label="Current password" type="password" required value={form.currentPassword} onChange={(e) => setForm({ ...form, currentPassword: e.target.value })} />
      <Input label="New password" type="password" required minLength={8} value={form.newPassword} onChange={(e) => setForm({ ...form, newPassword: e.target.value })} />
      {status && <Alert type={status.type}>{status.text}</Alert>}
      <Button type="submit" disabled={loading}>{loading ? 'Saving…' : 'Update password'}</Button>
    </form>
  );
}

/**
 * Tier 1→2 needs a NIN + a photo of the NIN slip + address. Tier 2→3 only
 * needs a utility bill (address is already on file from Tier 2). Submits to
 * POST /users/tier-upgrade, which files the request for admin review —
 * status shows up as "Pending review" above once submitted.
 */
function TierUpgradeForm({ profile, onSubmitted }) {
  const movingToTier = profile.kyc_tier + 1;
  const [form, setForm] = useState({ nin: '', address: profile.address || '' });
  const [file, setFile] = useState(null);
  const [fileName, setFileName] = useState(null);
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setStatus(null);
    if (!file) return setStatus({ type: 'error', text: movingToTier === 2 ? 'Please attach your NIN slip.' : 'Please attach a recent utility bill.' });
    setLoading(true);
    try {
      const fd = new FormData();
      if (movingToTier === 2) {
        fd.append('nin', form.nin);
        fd.append('address', form.address);
        fd.append('ninSlip', file);
      } else {
        fd.append('utilityBill', file);
      }
      await apiFetch('/users/tier-upgrade', { method: 'POST', body: fd, isForm: true });
      setStatus({ type: 'success', text: 'Tier upgrade request submitted for review.' });
      setFile(null);
      setFileName(null);
      onSubmitted?.();
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={submit} className="space-y-4 rounded-xl2 border border-line bg-white p-6 shadow-card">
      <h2 className="font-display text-lg text-ink">Verify Tier {movingToTier}</h2>
      <p className="text-sm text-slate">
        {movingToTier === 2
          ? 'Add your NIN, a photo of your NIN slip, and your address to raise your transaction limits.'
          : 'Upload a recent utility bill matching the address on your account to raise your transaction limits further.'}
      </p>

      {movingToTier === 2 && (
        <>
          <Input label="NIN" required maxLength={11} placeholder="11 digits" value={form.nin} onChange={(e) => setForm({ ...form, nin: e.target.value.replace(/\D/g, '') })} />
          <Input label="Address" required value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
        </>
      )}

      <label className="block">
        <span className="mb-1.5 block text-sm font-medium text-ink">{movingToTier === 2 ? 'NIN slip photo' : 'Utility bill'}</span>
        <input
          type="file" accept="image/jpeg,image/png,image/webp,application/pdf" required
          onChange={(e) => { const f = e.target.files[0]; setFile(f || null); setFileName(f ? f.name : null); }}
          className="w-full rounded-lg border border-line bg-white px-3.5 py-2.5 text-sm text-ink file:mr-3 file:rounded-md file:border-0 file:bg-paper file:px-3 file:py-1.5 file:text-sm"
        />
        {fileName && <span className="mt-1 block text-xs text-unlock">Selected: {fileName}</span>}
      </label>

      {status && <Alert type={status.type}>{status.text}</Alert>}
      <Button type="submit" disabled={loading}>{loading ? 'Submitting…' : 'Submit for review'}</Button>
    </form>
  );
}
