import Link from 'next/link';
import DashboardShell from '../../../components/DashboardShell';
import AdSlot from '../../../components/AdSlot';

const ITEMS = [
  { href: '/dashboard/transactions', icon: '📄', title: 'Transactions', body: 'Every transfer, deposit, and bill payment on your account.' },
  { href: '/dashboard/statement', icon: '🧾', title: 'Statement of account', body: 'Download a PDF statement for any date range.' },
  { href: '/dashboard/offline', icon: '🔒', title: 'Offline mode', body: 'See how much of your balance stays spendable without a connection.' },
];

export default function FinancePage() {
  return (
    <DashboardShell>
      <h1 className="font-display text-2xl text-ink">Finance</h1>
      <p className="mt-1 text-sm text-slate">Everything about your money in one place.</p>

      <div className="mt-6 space-y-3">
        {ITEMS.map((item) => (
          <Link key={item.href} href={item.href} className="flex items-center gap-4 rounded-xl2 border border-line bg-white p-5 shadow-card hover:bg-paper">
            <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-paper text-xl">{item.icon}</span>
            <div>
              <p className="font-medium text-ink">{item.title}</p>
              <p className="text-sm text-slate">{item.body}</p>
            </div>
          </Link>
        ))}
      </div>

      <div className="mt-8">
        <AdSlot page="finance" slot="bottom" />
      </div>
    </DashboardShell>
  );
}
