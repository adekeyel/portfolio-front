'use client';
import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import DashboardShell from '../../../../components/DashboardShell';
import Input from '../../../../components/Input';
import Button from '../../../../components/Button';
import Alert from '../../../../components/Alert';
import { apiFetch } from '../../../../lib/api';

const META = {
  airtime: { title: 'Buy airtime', recipientLabel: 'Phone number', recipientPlaceholder: '080XXXXXXXX', freeAmount: true },
  data: { title: 'Buy data', recipientLabel: 'Phone number', recipientPlaceholder: '080XXXXXXXX', freeAmount: false },
  cable: { title: 'Cable TV subscription', recipientLabel: 'Smartcard / IUC number', recipientPlaceholder: 'e.g. 1234567890', freeAmount: false },
  electricity: { title: 'Buy electricity', recipientLabel: 'Meter number', recipientPlaceholder: 'e.g. 04512345678', freeAmount: true },
};

export default function VtuCategoryPage() {
  const { category } = useParams();
  const router = useRouter();
  const meta = META[category];

  const [providers, setProviders] = useState([]);
  const [plans, setPlans] = useState([]);
  const [provider, setProvider] = useState('');
  const [productId, setProductId] = useState('');
  const [recipient, setRecipient] = useState('');
  const [amount, setAmount] = useState('');
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!meta) return;
    apiFetch(`/vtu/products/${category}`).then((res) => {
      setProviders(res.data.providers);
      setPlans(res.data.plans);
      if (res.data.providers.length) setProvider(res.data.providers[0]);
    }).catch((err) => setStatus({ type: 'error', text: err.message }));
  }, [category]);

  if (!meta) {
    return <DashboardShell><Alert type="error">Unknown VTU category.</Alert></DashboardShell>;
  }

  const providerPlans = plans.filter((p) => p.provider === provider);

  async function submit(e) {
    e.preventDefault();
    setStatus(null);
    setLoading(true);
    try {
      const body = { category, provider, recipient };
      if (meta.freeAmount) body.amount = parseFloat(amount);
      else body.productId = productId;

      const res = await apiFetch('/vtu/purchase', { method: 'POST', body });
      setStatus({ type: 'success', text: res.message });
      setRecipient('');
      setAmount('');
      setProductId('');
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    } finally {
      setLoading(false);
    }
  }

  return (
    <DashboardShell>
      <h1 className="font-display text-2xl text-ink">{meta.title}</h1>

      <form onSubmit={submit} className="mt-6 max-w-md space-y-4 rounded-xl2 border border-line bg-white p-6 shadow-card">
        <label className="block">
          <span className="mb-1.5 block text-sm font-medium text-ink">Provider</span>
          <select value={provider} onChange={(e) => { setProvider(e.target.value); setProductId(''); }} className="w-full rounded-lg border border-line bg-white px-3.5 py-2.5 text-sm">
            {providers.map((p) => <option key={p} value={p}>{p}</option>)}
          </select>
        </label>

        <Input
          label={meta.recipientLabel} placeholder={meta.recipientPlaceholder} required
          value={recipient} onChange={(e) => setRecipient(e.target.value)}
        />

        {meta.freeAmount ? (
          <Input label="Amount (₦)" type="number" min="50" step="1" required value={amount} onChange={(e) => setAmount(e.target.value)} />
        ) : (
          <label className="block">
            <span className="mb-1.5 block text-sm font-medium text-ink">Plan</span>
            <select value={productId} onChange={(e) => setProductId(e.target.value)} required className="w-full rounded-lg border border-line bg-white px-3.5 py-2.5 text-sm">
              <option value="">Select a plan…</option>
              {providerPlans.map((p) => <option key={p.id} value={p.id}>{p.name} — ₦{Number(p.amount).toLocaleString()}</option>)}
            </select>
          </label>
        )}

        {status && <Alert type={status.type}>{status.text}</Alert>}
        <Button type="submit" className="w-full" disabled={loading}>{loading ? 'Processing…' : `Pay${meta.freeAmount && amount ? ` ₦${Number(amount).toLocaleString()}` : ''}`}</Button>
      </form>
    </DashboardShell>
  );
}
