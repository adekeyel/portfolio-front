'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import DashboardShell from '../../components/DashboardShell';
import LockRing from '../../components/LockRing';
import StatCard from '../../components/StatCard';
import TransactionRow from '../../components/TransactionRow';
import Alert from '../../components/Alert';
import AdSlot from '../../components/AdSlot';
import { apiFetch, downloadFile } from '../../lib/api';
import { cacheWalletSummary, getCachedWalletSummary } from '../../lib/offlineDb';

const VTU_SHORTCUTS = [
  { category: 'airtime', label: 'Airtime', icon: '📶' },
  { category: 'data', label: 'Data', icon: '🌐' },
  { category: 'cable', label: 'Cable TV', icon: '📺' },
  { category: 'electricity', label: 'Electricity', icon: '⚡' },
];

export default function DashboardPage() {
  const [summary, setSummary] = useState(null);
  const [txns, setTxns] = useState([]);
  const [isOffline, setIsOffline] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    load();
  }, []);

  async function load() {
    try {
      const res = await apiFetch('/wallet/summary');
      setSummary(res.data);
      await cacheWalletSummary(res.data);
      setIsOffline(false);
    } catch (err) {
      // No connectivity — fall back to the last cached wallet summary
      const cached = await getCachedWalletSummary();
      if (cached) {
        setSummary(cached);
        setIsOffline(true);
      } else {
        setError(err.message);
      }
    }
    try {
      const txRes = await apiFetch('/transactions?limit=6');
      setTxns(txRes.data);
    } catch {
      /* ignore when offline */
    }
  }

  async function downloadReceipt(id) {
    try {
      await downloadFile(`/transactions/${id}/receipt`, `OffPay-Receipt-${id}.pdf`);
    } catch (err) {
      setError(err.message);
    }
  }

  if (error) return <DashboardShell><Alert type="error">{error}</Alert></DashboardShell>;
  if (!summary) return <DashboardShell><p className="text-sm text-slate">Loading your wallet…</p></DashboardShell>;

  return (
    <DashboardShell>
      <div className="grid gap-8 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-6">
          <div className="rounded-xl2 border border-line bg-white p-6 shadow-card">
            <p className="text-xs uppercase tracking-wide text-slate">Wallet balance</p>
            <p className="mt-1 font-mono text-3xl font-semibold text-ink">₦{Number(summary.balance).toLocaleString()}</p>
            <p className="mt-1 font-mono text-xs text-slate">{summary.walletId} · {summary.accountNumber || 'Awaiting verification'} {summary.bankName ? `· ${summary.bankName}` : ''}</p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Link href="/dashboard/send" className="rounded-lg bg-ink px-4 py-2 text-sm font-semibold text-white hover:bg-ink-700">Send money</Link>
              <Link href="/dashboard/receive" className="rounded-lg border border-line px-4 py-2 text-sm font-semibold text-ink hover:bg-paper">Receive</Link>
              <Link href="/dashboard/offline" className="rounded-lg border border-line px-4 py-2 text-sm font-semibold text-ink hover:bg-paper">Offline mode</Link>
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <StatCard label="Available if offline now" value={`₦${summary.offlineLock.wouldBeAvailable.toLocaleString()}`} sub={`${summary.offlineLock.availablePercent}% of balance`} accent="unlock" />
            <StatCard label="Would lock if offline now" value={`₦${summary.offlineLock.wouldLock.toLocaleString()}`} sub={`${summary.offlineLock.lockPercent}% of balance`} accent="lock" />
          </div>

          <div className="rounded-xl2 border border-line bg-white p-6 shadow-card">
            <h2 className="font-display text-lg text-ink">Airtime, data & bills</h2>
            <div className="mt-4 grid grid-cols-4 gap-3">
              {VTU_SHORTCUTS.map((v) => (
                <Link key={v.category} href={`/dashboard/vtu/${v.category}`} className="flex flex-col items-center gap-2 rounded-lg p-2 text-center hover:bg-paper">
                  <span className="flex h-12 w-12 items-center justify-center rounded-full bg-paper text-xl">{v.icon}</span>
                  <span className="text-xs font-medium text-ink">{v.label}</span>
                </Link>
              ))}
            </div>
          </div>

          <AdSlot page="dashboard" slot="middle" />

          <div className="rounded-xl2 border border-line bg-white p-6 shadow-card">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-lg text-ink">Recent activity</h2>
              <Link href="/dashboard/transactions" className="text-xs font-medium text-ink underline">View all</Link>
            </div>
            <div className="mt-3">
              {txns.length === 0 && <p className="py-6 text-center text-sm text-slate">No transactions yet. Fund your wallet to get started.</p>}
              {txns.map((t) => <TransactionRow key={t.id} txn={t} onDownloadReceipt={downloadReceipt} />)}
            </div>
          </div>
        </div>

        <div className="rounded-xl2 border border-line bg-white p-6 shadow-card">
          <h2 className="text-center font-display text-lg text-ink">Offline lock preview</h2>
          <p className="mt-1 text-center text-xs text-slate">This is what your balance would look like the instant you disconnect.</p>
          <div className="mt-6 flex justify-center">
            <LockRing balance={summary.balance} availablePercent={summary.offlineLock.availablePercent} mode="locked" />
          </div>
          {isOffline && <Alert type="warning">You're viewing cached data — connect to refresh your live balance.</Alert>}
        </div>
      </div>
    </DashboardShell>
  );
}
