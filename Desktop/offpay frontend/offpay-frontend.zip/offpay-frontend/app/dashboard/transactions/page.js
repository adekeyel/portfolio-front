'use client';
import { useEffect, useState } from 'react';
import DashboardShell from '../../../components/DashboardShell';
import TransactionRow from '../../../components/TransactionRow';
import Alert from '../../../components/Alert';
import { apiFetch, downloadFile } from '../../../lib/api';

export default function TransactionsPage() {
  const [txns, setTxns] = useState([]);
  const [error, setError] = useState(null);
  const [filter, setFilter] = useState('');

  useEffect(() => {
    load();
  }, [filter]);

  async function load() {
    try {
      const res = await apiFetch(`/transactions?limit=50${filter ? `&type=${filter}` : ''}`);
      setTxns(res.data);
    } catch (err) {
      setError(err.message);
    }
  }

  async function downloadReceipt(id) {
    try {
      await downloadFile(`/transactions/${id}/receipt`, `OffPay-Receipt-${id}.pdf`);
    } catch (err) {
      setError(err.message);
    }
  }

  const filters = [
    { key: '', label: 'All' },
    { key: 'deposit_external', label: 'Deposits' },
    { key: 'withdrawal_external', label: 'Bank transfers' },
    { key: 'transfer_in_app', label: 'In-app' },
    { key: 'transfer_offline', label: 'Offline' },
    { key: 'reversal', label: 'Reversals' },
  ];

  return (
    <DashboardShell>
      <h1 className="font-display text-2xl text-ink">Transactions</h1>
      <div className="mt-4 flex flex-wrap gap-2">
        {filters.map((f) => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            className={`rounded-full border px-3.5 py-1.5 text-xs font-medium ${filter === f.key ? 'border-ink bg-ink text-white' : 'border-line bg-white text-ink/70'}`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {error && <div className="mt-4"><Alert type="error">{error}</Alert></div>}

      <div className="mt-6 rounded-xl2 border border-line bg-white p-6 shadow-card">
        {txns.length === 0 ? (
          <p className="py-10 text-center text-sm text-slate">No transactions found.</p>
        ) : (
          txns.map((t) => <TransactionRow key={t.id} txn={t} onDownloadReceipt={downloadReceipt} />)
        )}
      </div>
    </DashboardShell>
  );
}
