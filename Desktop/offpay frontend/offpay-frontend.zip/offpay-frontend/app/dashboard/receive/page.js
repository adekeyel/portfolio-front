'use client';
import { useEffect, useState } from 'react';
import DashboardShell from '../../../components/DashboardShell';
import Alert from '../../../components/Alert';
import Input from '../../../components/Input';
import Button from '../../../components/Button';
import { apiFetch } from '../../../lib/api';

export default function ReceivePage() {
  const [summary, setSummary] = useState(null);
  const [copyStatus, setCopyStatus] = useState('');
  const [sim, setSim] = useState({ amount: '', senderName: '', senderBank: '' });
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    apiFetch('/wallet/summary').then((res) => setSummary(res.data)).catch(() => {});
  }, []);

  function copyAccount() {
    navigator.clipboard.writeText(summary.accountNumber);
    setCopyStatus('Copied!');
    setTimeout(() => setCopyStatus(''), 2000);
  }

  async function simulateDeposit(e) {
    e.preventDefault();
    setStatus(null);
    setLoading(true);
    try {
      const res = await apiFetch('/transactions/simulate-deposit', { method: 'POST', body: { ...sim, amount: parseFloat(sim.amount) } });
      setStatus({ type: 'success', text: `Deposit received. ₦${res.data.netCredit} credited after a ₦${res.data.fee} fee.` });
      const refreshed = await apiFetch('/wallet/summary');
      setSummary(refreshed.data);
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    } finally {
      setLoading(false);
    }
  }

  return (
    <DashboardShell>
      <h1 className="font-display text-2xl text-ink">Receive money</h1>

      {!summary ? (
        <p className="mt-4 text-sm text-slate">Loading…</p>
      ) : !summary.accountNumber ? (
        <Alert type="warning">Your virtual account is issued once KYC verification is approved. Check back soon.</Alert>
      ) : (
        <div className="mt-6 max-w-md rounded-xl2 border border-line bg-white p-6 shadow-card">
          <p className="text-xs uppercase tracking-wide text-slate">Share this account for bank transfers</p>
          <p className="mt-2 font-mono text-2xl font-semibold text-ink">{summary.accountNumber}</p>
          <p className="text-sm text-slate">{summary.bankName}</p>
          <p className="mt-4 text-xs text-slate">Wallet ID (for OffPay-to-OffPay transfers)</p>
          <p className="font-mono text-sm text-ink">{summary.walletId}</p>
          <Button variant="ghost" className="mt-4" onClick={copyAccount}>{copyStatus || 'Copy account number'}</Button>
        </div>
      )}

      <div className="mt-10 max-w-md rounded-xl2 border border-dashed border-line bg-white p-6">
        <h2 className="font-display text-lg text-ink">Sandbox: simulate an incoming deposit</h2>
        <p className="mt-1 text-xs text-slate">
          For demo/testing without live provider credentials. In production this happens
          automatically via the Flutterwave/Paystack webhook when someone sends to your
          virtual account.
        </p>
        <form onSubmit={simulateDeposit} className="mt-4 space-y-3">
          <Input label="Amount (₦)" type="number" min="1" required value={sim.amount} onChange={(e) => setSim({ ...sim, amount: e.target.value })} />
          <Input label="Sender name" value={sim.senderName} onChange={(e) => setSim({ ...sim, senderName: e.target.value })} />
          <Input label="Sender bank" value={sim.senderBank} onChange={(e) => setSim({ ...sim, senderBank: e.target.value })} />
          {status && <Alert type={status.type}>{status.text}</Alert>}
          <Button type="submit" variant="ghost" disabled={loading}>{loading ? 'Processing…' : 'Simulate deposit'}</Button>
        </form>
      </div>
    </DashboardShell>
  );
}
