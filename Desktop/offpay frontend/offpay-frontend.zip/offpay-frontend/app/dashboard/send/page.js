'use client';
import { useEffect, useState } from 'react';
import DashboardShell from '../../../components/DashboardShell';
import Input from '../../../components/Input';
import Button from '../../../components/Button';
import Alert from '../../../components/Alert';
import { apiFetch } from '../../../lib/api';

export default function SendPage() {
  const [tab, setTab] = useState('bank'); // 'bank' | 'app'
  return (
    <DashboardShell>
      <h1 className="font-display text-2xl text-ink">Send money</h1>
      <div className="mt-4 inline-flex rounded-lg border border-line bg-white p-1">
        <TabButton active={tab === 'bank'} onClick={() => setTab('bank')}>To a bank account</TabButton>
        <TabButton active={tab === 'app'} onClick={() => setTab('app')}>To a OffPay user</TabButton>
      </div>
      <div className="mt-6 max-w-lg">
        {tab === 'bank' ? <SendToBankForm /> : <SendInAppForm />}
      </div>
    </DashboardShell>
  );
}

function TabButton({ active, onClick, children }) {
  return (
    <button onClick={onClick} className={`rounded-md px-4 py-2 text-sm font-medium ${active ? 'bg-ink text-white' : 'text-ink/70'}`}>
      {children}
    </button>
  );
}

function SendToBankForm() {
  const [banks, setBanks] = useState([]);
  const [form, setForm] = useState({ bankCode: '', bankName: '', accountNumber: '', accountName: '', amount: '', narration: '', pin: '' });
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(false);
  const otp = useTransferOtp();

  useEffect(() => {
    apiFetch('/banks').then((res) => {
      setBanks(res.data);
      if (res.warning) setStatus({ type: 'error', text: res.warning });
    }).catch(() => {});
  }, []);

  function onBankChange(e) {
    const selected = banks.find((b) => b.code === e.target.value);
    setForm({ ...form, bankCode: e.target.value, bankName: selected?.name || '' });
  }

  async function submit(e) {
    e.preventDefault();
    setStatus(null);
    setLoading(true);
    try {
      const res = await apiFetch('/transactions/send-to-bank', { method: 'POST', body: { ...form, amount: parseFloat(form.amount), otpCode: otp.code || undefined } });
      setStatus({ type: 'success', text: `Transfer sent. Reference ${res.data.reference}. Fee charged: ₦${res.data.fee}.` });
      setForm({ bankCode: '', bankName: '', accountNumber: '', accountName: '', amount: '', narration: '', pin: '' });
      otp.reset();
    } catch (err) {
      if (!otp.handleError(err)) setStatus({ type: 'error', text: err.message });
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={submit} className="space-y-4 rounded-xl2 border border-line bg-white p-6 shadow-card">
      <label className="block">
        <span className="mb-1.5 block text-sm font-medium text-ink">Bank</span>
        <select required value={form.bankCode} onChange={onBankChange} className="w-full rounded-lg border border-line bg-white px-3.5 py-2.5 text-sm text-ink">
          <option value="">Select bank</option>
          {banks.map((b) => <option key={b.code} value={b.code}>{b.name}</option>)}
        </select>
      </label>
      <Input label="Account number" required maxLength={10} value={form.accountNumber} onChange={(e) => setForm({ ...form, accountNumber: e.target.value })} />
      <Input label="Account name" required value={form.accountName} onChange={(e) => setForm({ ...form, accountName: e.target.value })} />
      <Input label="Amount (₦)" type="number" min="100" required value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} />
      <Input label="Narration (optional)" value={form.narration} onChange={(e) => setForm({ ...form, narration: e.target.value })} />
      <Input label="Transaction PIN" type="password" maxLength={4} required value={form.pin} onChange={(e) => setForm({ ...form, pin: e.target.value })} />
      <otp.Field />
      {status && <Alert type={status.type}>{status.text}</Alert>}
      <Button type="submit" className="w-full" disabled={loading}>{loading ? 'Sending…' : 'Send transfer'}</Button>
    </form>
  );
}

function SendInAppForm() {
  const [form, setForm] = useState({ recipientWalletId: '', amount: '', narration: '', pin: '' });
  const [resolvedName, setResolvedName] = useState(null);
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(false);
  const otp = useTransferOtp();

  async function resolveRecipient() {
    if (!form.recipientWalletId) return;
    try {
      const res = await apiFetch(`/wallet/resolve?walletId=${encodeURIComponent(form.recipientWalletId)}`);
      setResolvedName(res.data.accountName);
    } catch {
      setResolvedName(null);
    }
  }

  async function submit(e) {
    e.preventDefault();
    setStatus(null);
    setLoading(true);
    try {
      const res = await apiFetch('/transactions/send-in-app', { method: 'POST', body: { ...form, amount: parseFloat(form.amount), otpCode: otp.code || undefined } });
      setStatus({ type: 'success', text: `Transfer successful. Reference ${res.data.reference}. Fee charged: ₦${res.data.fee}.` });
      setForm({ recipientWalletId: '', amount: '', narration: '', pin: '' });
      setResolvedName(null);
      otp.reset();
    } catch (err) {
      if (!otp.handleError(err)) setStatus({ type: 'error', text: err.message });
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={submit} className="space-y-4 rounded-xl2 border border-line bg-white p-6 shadow-card">
      <Input
        label="Recipient Wallet ID" required placeholder="OP-XXXX-XXXX"
        value={form.recipientWalletId}
        onChange={(e) => setForm({ ...form, recipientWalletId: e.target.value })}
        onBlur={resolveRecipient}
      />
      {resolvedName && <Alert type="success">Sending to: {resolvedName}</Alert>}
      <Input label="Amount (₦)" type="number" min="1" required value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} />
      <Input label="Narration (optional)" value={form.narration} onChange={(e) => setForm({ ...form, narration: e.target.value })} />
      <Input label="Transaction PIN" type="password" maxLength={4} required value={form.pin} onChange={(e) => setForm({ ...form, pin: e.target.value })} />
      <otp.Field />
      <p className="text-xs text-slate">Flat fee: ₦10, regardless of amount.</p>
      {status && <Alert type={status.type}>{status.text}</Alert>}
      <Button type="submit" className="w-full" disabled={loading}>{loading ? 'Sending…' : 'Send transfer'}</Button>
    </form>
  );
}

/**
 * Shared logic for both transfer forms: catches the backend's
 * TRANSFER_OTP_REQUIRED signal (see security.service.js enforceTransferOtp)
 * and renders the right follow-up field — a Google Authenticator code entry,
 * or an emailed-code entry with a "Send code" button. Only ever triggered on
 * this online send flow; offline queued transfers (Send > Offline) never hit
 * this because that endpoint doesn't call enforceTransferOtp at all.
 */
function useTransferOtp() {
  const [required, setRequired] = useState(null); // null | 'google' | 'email'
  const [code, setCode] = useState('');
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);

  function handleError(err) {
    if (err.details?.code === 'TRANSFER_OTP_REQUIRED') {
      setRequired(err.details.method);
      return true;
    }
    return false;
  }

  function reset() {
    setRequired(null);
    setCode('');
    setSent(false);
  }

  async function sendEmailCode() {
    setSending(true);
    try {
      await apiFetch('/security/transfer-otp/request', { method: 'POST' });
      setSent(true);
    } finally {
      setSending(false);
    }
  }

  function Field() {
    if (!required) return null;
    return (
      <div className="space-y-2 rounded-lg border border-line bg-paper p-3">
        <p className="text-xs font-medium text-ink">
          {required === 'google' ? 'Enter the 6-digit code from your authenticator app.' : 'Enter the OTP sent to your email.'}
        </p>
        {required === 'email' && (
          <Button type="button" variant="ghost" onClick={sendEmailCode} disabled={sending}>
            {sending ? 'Sending…' : sent ? 'Resend code' : 'Send code'}
          </Button>
        )}
        <Input label="Verification code" maxLength={6} value={code} onChange={(e) => { setCode(e.target.value.replace(/\D/g, '')); }} />
      </div>
    );
  }

  return { code, handleError, reset, Field };
}
