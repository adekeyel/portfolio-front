import DashboardShell from '../../../components/DashboardShell';

export default function RewardsPage() {
  return (
    <DashboardShell>
      <h1 className="font-display text-2xl text-ink">Rewards</h1>
      <div className="mt-6 rounded-xl2 border border-line bg-white p-10 text-center shadow-card">
        <p className="text-4xl">🎁</p>
        <p className="mt-3 font-display text-lg text-ink">Coming soon</p>
        <p className="mx-auto mt-2 max-w-sm text-sm text-slate">
          Cashback, vouchers, and referral bonuses will live here. This tab exists now so the
          navigation matches, but the rewards engine itself hasn't been built yet.
        </p>
      </div>
    </DashboardShell>
  );
}
