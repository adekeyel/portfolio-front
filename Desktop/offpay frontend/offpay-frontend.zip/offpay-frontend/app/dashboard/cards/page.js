'use client';
import { useEffect, useState } from 'react';
import DashboardShell from '../../../components/DashboardShell';
import Button from '../../../components/Button';
import Alert from '../../../components/Alert';
import AdSlot from '../../../components/AdSlot';
import { apiFetch } from '../../../lib/api';

const STATUS_STYLE = {
  active: 'bg-unlock-dim text-unlock',
  frozen: 'bg-blue-50 text-blue-700',
  blocked: 'bg-red-50 text-danger',
  expired: 'bg-slate-100 text-slate',
};

export default function CardsPage() {
  const [card, setCard] = useState(undefined); // undefined = loading, null = none yet
  const [status, setStatus] = useState(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => { load(); }, []);

  async function load() {
    try {
      const res = await apiFetch('/cards/mine');
      setCard(res.data);
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    }
  }

  async function create() {
    setBusy(true);
    setStatus(null);
    try {
      await apiFetch('/cards', { method: 'POST' });
      setStatus({ type: 'success', text: 'Your virtual card is ready.' });
      await load();
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    } finally {
      setBusy(false);
    }
  }

  async function act(action) {
    setBusy(true);
    setStatus(null);
    try {
      await apiFetch(`/cards/${card.id}/status`, { method: 'POST', body: { action } });
      await load();
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    } finally {
      setBusy(false);
    }
  }

  return (
    <DashboardShell>
      <h1 className="font-display text-2xl text-ink">Cards</h1>
      {status && <div className="mt-4 max-w-md"><Alert type={status.type}>{status.text}</Alert></div>}

      {card === undefined && <p className="mt-6 text-sm text-slate">Loading…</p>}

      {card === null && (
        <div className="mt-6 max-w-md rounded-xl2 border border-line bg-white p-8 text-center shadow-card">
          <p className="text-4xl">💳</p>
          <p className="mt-3 font-display text-lg text-ink">Get a virtual card</p>
          <p className="mt-2 text-sm text-slate">Spend online anywhere Verve is accepted, funded straight from your OffPay wallet.</p>
          <Button className="mt-5" onClick={create} disabled={busy}>{busy ? 'Creating…' : 'Create virtual card'}</Button>
        </div>
      )}

      {card && (
        <div className="mt-6 max-w-md space-y-5">
          <div className="rounded-xl2 bg-gradient-to-br from-ink to-ink-700 p-6 text-white shadow-card">
            <div className="flex items-center justify-between">
              <span className="font-display text-lg">Off<span className="text-unlock">Pay</span></span>
              <span className="text-xs uppercase tracking-wide text-white/60">{card.brand}</span>
            </div>
            <p className="mt-8 font-mono text-xl tracking-widest">{card.masked_pan}</p>
            <div className="mt-4 flex items-center justify-between text-xs text-white/70">
              <span>Expires {String(card.expiry_month).padStart(2, '0')}/{card.expiry_year}</span>
              <span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${STATUS_STYLE[card.status]}`}>{card.status}</span>
            </div>
          </div>

          <p className="text-xs text-slate">
            For your security, the full card number and CVV are only ever shown once by our card partner directly —
            we don't store or display them here after that.
          </p>

          <div className="flex flex-wrap gap-2">
            {card.status === 'active' && <Button variant="ghost" onClick={() => act('freeze')} disabled={busy}>Freeze card</Button>}
            {card.status === 'frozen' && <Button variant="ghost" onClick={() => act('unfreeze')} disabled={busy}>Unfreeze card</Button>}
            {card.status !== 'blocked' && card.status !== 'expired' && (
              <Button variant="danger" onClick={() => act('block')} disabled={busy}>Block permanently</Button>
            )}
          </div>
        </div>
      )}

      <div className="mt-8"><AdSlot page="cards" slot="bottom" /></div>
    </DashboardShell>
  );
}
