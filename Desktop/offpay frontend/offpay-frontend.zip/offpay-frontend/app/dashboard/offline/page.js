'use client';
import { useEffect, useState, useCallback } from 'react';
import DashboardShell from '../../../components/DashboardShell';
import LockRing from '../../../components/LockRing';
import Input from '../../../components/Input';
import Button from '../../../components/Button';
import Alert from '../../../components/Alert';
import { apiFetch } from '../../../lib/api';
import {
  saveOfflineToken, getOfflineToken, clearOfflineToken,
  queueLocalTransaction, getQueuedTransactions, removeQueuedTransaction, getTotalLocalSpend,
} from '../../../lib/offlineDb';

export default function OfflinePage() {
  const [isOnline, setIsOnline] = useState(true);
  const [token, setToken] = useState(null);
  const [queued, setQueued] = useState([]);
  const [form, setForm] = useState({ recipientWalletId: '', amount: '', narration: '' });
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(false);

  const refreshQueue = useCallback(async () => {
    setQueued(await getQueuedTransactions());
  }, []);

  useEffect(() => {
    setIsOnline(navigator.onLine);
    getOfflineToken().then(setToken);
    refreshQueue();
    const onUp = () => setIsOnline(true);
    const onDown = () => setIsOnline(false);
    window.addEventListener('online', onUp);
    window.addEventListener('offline', onDown);
    return () => {
      window.removeEventListener('online', onUp);
      window.removeEventListener('offline', onDown);
    };
  }, [refreshQueue]);

  async function prepareOfflineMode() {
    setStatus(null);
    setLoading(true);
    try {
      const res = await apiFetch('/wallet/offline-token', { method: 'POST' });
      await saveOfflineToken(res.data);
      setToken(res.data);
      setStatus({ type: 'success', text: res.message });
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    } finally {
      setLoading(false);
    }
  }

  async function queuePayment(e) {
    e.preventDefault();
    setStatus(null);
    if (!token) return setStatus({ type: 'error', text: 'Prepare offline mode first, while you still have a connection.' });

    const amount = parseFloat(form.amount);
    const alreadySpent = await getTotalLocalSpend();
    if (alreadySpent + amount > token.offlineLimit) {
      return setStatus({
        type: 'error',
        text: `This would exceed your offline limit of ₦${token.offlineLimit.toLocaleString()}. ₦${(token.offlineLimit - alreadySpent).toLocaleString()} remains available offline.`,
      });
    }

    const txn = {
      recipientWalletId: form.recipientWalletId,
      amount,
      narration: form.narration,
      idempotencyKey: crypto.randomUUID(),
      deviceCreatedAt: new Date().toISOString(),
    };
    await queueLocalTransaction(txn);
    await refreshQueue();
    setForm({ recipientWalletId: '', amount: '', narration: '' });
    setStatus({ type: 'success', text: 'Payment queued on this device. It will settle automatically once you reconnect.' });
  }

  async function syncNow() {
    setStatus(null);
    setLoading(true);
    try {
      const transactions = await getQueuedTransactions();
      const savedToken = await getOfflineToken();
      const res = await apiFetch('/wallet/offline-sync', {
        method: 'POST',
        body: { offlineToken: savedToken.token, transactions },
      });
      for (const r of res.data) {
        await removeQueuedTransaction(r.idempotencyKey);
      }
      await clearOfflineToken();
      setToken(null);
      await refreshQueue();
      setStatus({ type: 'success', text: res.message });
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    } finally {
      setLoading(false);
    }
  }

  const localSpend = queued.reduce((s, t) => s + parseFloat(t.amount), 0);

  return (
    <DashboardShell>
      <h1 className="font-display text-2xl text-ink">Offline mode</h1>
      <p className="mt-1 max-w-xl text-sm text-slate">
        Prepare offline mode while you have a connection. If you lose signal, you can
        still pay other OffPay users up to your protected 40% allowance — everything
        settles automatically the moment you're back online.
      </p>

      <div className="mt-8 grid gap-8 lg:grid-cols-2">
        <div className="rounded-xl2 border border-line bg-white p-6 shadow-card">
          <p className={`mb-4 text-xs font-semibold uppercase tracking-wide ${isOnline ? 'text-unlock' : 'text-lock'}`}>
            {isOnline ? '● Connected' : '● No connection detected'}
          </p>

          {!token ? (
            <>
              <p className="text-sm text-slate">No active offline session. Prepare one now while you're online.</p>
              <Button className="mt-4" onClick={prepareOfflineMode} disabled={loading || !isOnline}>
                {loading ? 'Preparing…' : 'Prepare offline mode'}
              </Button>
              {!isOnline && <p className="mt-2 text-xs text-lock">You need a connection to issue a new offline token.</p>}
            </>
          ) : (
            <div className="flex flex-col items-center">
              <LockRing balance={token.balanceSnapshot} availablePercent={token.availablePercent} mode="locked" />
              <p className="mt-4 text-center text-xs text-slate">
                Offline session active until {new Date(token.expiresAt).toLocaleString('en-NG')}.
                <br />Spent so far offline: ₦{localSpend.toLocaleString()} of ₦{token.offlineLimit.toLocaleString()}
              </p>
              {isOnline && (
                <Button variant="ghost" className="mt-4" onClick={syncNow} disabled={loading}>
                  {loading ? 'Syncing…' : `Sync ${queued.length} queued payment(s) now`}
                </Button>
              )}
            </div>
          )}
        </div>

        <div className="rounded-xl2 border border-line bg-white p-6 shadow-card">
          <h2 className="font-display text-lg text-ink">Pay a OffPay user offline</h2>
          <form onSubmit={queuePayment} className="mt-4 space-y-3">
            <Input label="Recipient Wallet ID" required placeholder="OP-XXXX-XXXX" value={form.recipientWalletId} onChange={(e) => setForm({ ...form, recipientWalletId: e.target.value })} />
            <Input label="Amount (₦)" type="number" min="1" required value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} />
            <Input label="Narration (optional)" value={form.narration} onChange={(e) => setForm({ ...form, narration: e.target.value })} />
            {status && <Alert type={status.type}>{status.text}</Alert>}
            <Button type="submit" className="w-full">Queue payment</Button>
          </form>
        </div>
      </div>

      {queued.length > 0 && (
        <div className="mt-8 rounded-xl2 border border-line bg-white p-6 shadow-card">
          <h2 className="font-display text-lg text-ink">Queued on this device</h2>
          <div className="mt-3 divide-y divide-line">
            {queued.map((t) => (
              <div key={t.idempotencyKey} className="flex items-center justify-between py-3 text-sm">
                <div>
                  <p className="font-medium text-ink">To {t.recipientWalletId}</p>
                  <p className="text-xs text-slate">{new Date(t.deviceCreatedAt).toLocaleString('en-NG')} · {t.narration || 'No note'}</p>
                </div>
                <p className="font-mono font-semibold text-ink">₦{Number(t.amount).toLocaleString()}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </DashboardShell>
  );
}
