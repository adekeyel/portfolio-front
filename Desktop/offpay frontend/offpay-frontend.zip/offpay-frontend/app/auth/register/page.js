'use client';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import MarketingNav from '../../../components/MarketingNav';
import Input from '../../../components/Input';
import Button from '../../../components/Button';
import Alert from '../../../components/Alert';
import { apiFetch, getOrCreateDeviceId } from '../../../lib/api';

// Persist entered fields (never the file itself — File objects can't survive
// serialization) so a backgrounded-tab reload doesn't wipe the whole form.
const DRAFT_KEY = 'op_register_draft';

function loadDraft() {
  if (typeof window === 'undefined') return null;
  try {
    return JSON.parse(sessionStorage.getItem(DRAFT_KEY) || 'null');
  } catch {
    return null;
  }
}

export default function RegisterPage() {
  const router = useRouter();
  const [form, setForm] = useState({ fullName: '', email: '', phone: '', bvn: '', password: '', dateOfBirth: '', sex: '' });
  const [passport, setPassport] = useState(null);
  const [passportName, setPassportName] = useState(null);
  const [restoredNotice, setRestoredNotice] = useState(false);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  // On mount, restore anything saved before a picker-triggered reload wiped
  // the page. The passport photo itself always has to be re-selected — file
  // handles never survive a reload — so we call that out explicitly rather
  // than let the "required" validation fail silently on submit.
  useEffect(() => {
    const draft = loadDraft();
    if (draft) {
      setForm((f) => ({ ...f, ...draft.form }));
      if (draft.hadPassport) {
        setRestoredNotice(true);
      }
    }
  }, []);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    sessionStorage.setItem(DRAFT_KEY, JSON.stringify({ form, hadPassport: !!passport || restoredNotice }));
  }, [form, passport, restoredNotice]);

  function update(key, value) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function submit(e) {
    e.preventDefault();
    setError(null);

    if (!passport) return setError('Please upload a clear passport photograph.');
    if (!/^\d{11}$/.test(form.bvn)) return setError('BVN must be exactly 11 digits.');
    if (form.password.length < 8) return setError('Password must be at least 8 characters.');
    if (!form.dateOfBirth) return setError('Date of birth is required.');
    if (!form.sex) return setError('Please select sex.');

    setLoading(true);
    try {
      const fd = new FormData();
      Object.entries(form).forEach(([k, v]) => fd.append(k, v));
      fd.append('passport', passport);

      const res = await apiFetch('/auth/register', { method: 'POST', body: fd, isForm: true });
      if (typeof window !== 'undefined') sessionStorage.removeItem(DRAFT_KEY);
      const deviceId = getOrCreateDeviceId();
      router.push(`/auth/verify-otp?userId=${res.data.userId}&email=${encodeURIComponent(res.data.email)}&deviceId=${deviceId}`);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div>
      <MarketingNav />
      <section className="mx-auto max-w-lg px-6 py-16">
        <h1 className="font-display text-3xl text-ink">Open your OffPay wallet</h1>
        <p className="mt-2 text-sm text-slate">
          Your full name must match your BVN record exactly — this is checked during
          verification.
        </p>

        <form onSubmit={submit} className="mt-8 space-y-4" encType="multipart/form-data">
          <Input label="Full name (as on your BVN)" required value={form.fullName} onChange={(e) => update('fullName', e.target.value)} />
          <Input label="Email address" type="email" required value={form.email} onChange={(e) => update('email', e.target.value)} />
          <Input label="Phone number" required placeholder="080XXXXXXXX" value={form.phone} onChange={(e) => update('phone', e.target.value)} />
          <Input label="Bank Verification Number (BVN)" required maxLength={11} placeholder="11 digits" value={form.bvn} onChange={(e) => update('bvn', e.target.value.replace(/\D/g, ''))} />
          <Input label="Date of birth" type="date" required value={form.dateOfBirth} onChange={(e) => update('dateOfBirth', e.target.value)} />
          <label className="block">
            <span className="mb-1.5 block text-sm font-medium text-ink">Sex</span>
            <select
              required value={form.sex} onChange={(e) => update('sex', e.target.value)}
              className="w-full rounded-lg border border-line bg-white px-3.5 py-2.5 text-sm"
            >
              <option value="" disabled>Select…</option>
              <option value="male">Male</option>
              <option value="female">Female</option>
            </select>
          </label>
          <Input label="Password" type="password" required minLength={8} value={form.password} onChange={(e) => update('password', e.target.value)} />

          <label className="block">
            <span className="mb-1.5 block text-sm font-medium text-ink">Passport photograph</span>
            <input
              type="file" accept="image/jpeg,image/png,image/webp" required={!passport}
              onChange={(e) => {
                const file = e.target.files[0];
                setPassport(file || null);
                setPassportName(file ? file.name : null);
                setRestoredNotice(false);
              }}
              className="w-full rounded-lg border border-line bg-white px-3.5 py-2.5 text-sm text-ink file:mr-3 file:rounded-md file:border-0 file:bg-paper file:px-3 file:py-1.5 file:text-sm"
            />
            {passportName && <span className="mt-1 block text-xs text-unlock">Selected: {passportName}</span>}
            <span className="mt-1 block text-xs text-slate">JPEG, PNG, or WEBP. Used only for identity verification.</span>
            {restoredNotice && !passport && (
              <span className="mt-1 block text-xs text-danger">
                Your other details were restored, but the photo has to be picked again — file selections don't survive
                the app being backgrounded (e.g. while browsing to another folder in the picker). Please choose it once more.
              </span>
            )}
          </label>

          {error && <Alert type="error">{error}</Alert>}

          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? 'Creating account…' : 'Create account'}
          </Button>
        </form>

        <p className="mt-6 text-center text-sm text-slate">
          Already have an account? <Link href="/auth/login" className="font-medium text-ink underline">Log in</Link>
        </p>
        <p className="mt-2 text-center text-xs text-slate">
          By continuing, you agree to our <Link href="/terms" className="underline">Terms</Link> and <Link href="/privacy" className="underline">Privacy Policy</Link>.
        </p>
      </section>
    </div>
  );
}
