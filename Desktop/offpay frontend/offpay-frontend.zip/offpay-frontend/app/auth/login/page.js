'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import MarketingNav from '../../../components/MarketingNav';
import Input from '../../../components/Input';
import Button from '../../../components/Button';
import Alert from '../../../components/Alert';
import { apiFetch, getOrCreateDeviceId, setAccessToken, setRefreshToken, setUnlockedThisSession } from '../../../lib/api';

export default function LoginPage() {
  const router = useRouter();
  const [form, setForm] = useState({ email: '', password: '' });
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const deviceId = getOrCreateDeviceId();
      const res = await apiFetch('/auth/login', { method: 'POST', body: { ...form, deviceId } });
      setAccessToken(res.data.accessToken);
      setRefreshToken(res.data.refreshToken);
      setUnlockedThisSession(true);
      router.push(res.data.appLockPinSet ? '/dashboard' : '/auth/set-pin');
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div>
      <MarketingNav />
      <section className="mx-auto max-w-md px-6 py-20">
        <h1 className="font-display text-3xl text-ink">Welcome back</h1>
        <p className="mt-2 text-sm text-slate">Log in to send, receive, and manage your wallet.</p>

        <form onSubmit={submit} className="mt-8 space-y-4">
          <Input label="Email address" type="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          <Input label="Password" type="password" required value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
          {error && <Alert type="error">{error}</Alert>}
          <Button type="submit" className="w-full" disabled={loading}>{loading ? 'Signing in…' : 'Continue'}</Button>
        </form>

        <p className="mt-6 text-center text-sm text-slate">
          New to OffPay? <Link href="/auth/register" className="font-medium text-ink underline">Create an account</Link>
        </p>
      </section>
    </div>
  );
}
