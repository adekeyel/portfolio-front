'use client';
import { Suspense, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Button from '../../../components/Button';
import Alert from '../../../components/Alert';
import { unlockWithPin, clearSession, hasKnownDevice } from '../../../lib/api';

function UnlockForm() {
  const router = useRouter();
  const params = useSearchParams();
  const next = params.get('next') || '/dashboard';

  const [digits, setDigits] = useState(['', '', '', '']);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  if (typeof window !== 'undefined' && !hasKnownDevice()) {
    router.replace('/auth/login');
    return null;
  }

  function updateDigit(i, value) {
    const v = value.replace(/\D/g, '').slice(-1);
    const updated = [...digits];
    updated[i] = v;
    setDigits(updated);
    if (v && i < 3) document.getElementById(`pin-${i + 1}`)?.focus();
    if (updated.every((d) => d !== '')) submit(updated.join(''));
  }

  async function submit(pin) {
    setError(null);
    setLoading(true);
    try {
      await unlockWithPin(pin);
      router.push(next);
    } catch (err) {
      setError(err.message);
      setDigits(['', '', '', '']);
      document.getElementById('pin-0')?.focus();
    } finally {
      setLoading(false);
    }
  }

  function useDifferentAccount() {
    clearSession();
    router.push('/auth/login');
  }

  return (
    <section className="mx-auto flex min-h-screen max-w-sm flex-col items-center justify-center px-6 text-center">
      <div className="flex h-14 w-14 items-center justify-center rounded-full bg-paper">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M6 11h12v9H6v-9Zm3 0V7a3 3 0 0 1 6 0v4" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" /></svg>
      </div>
      <h1 className="mt-5 font-display text-2xl text-ink">Welcome back</h1>
      <p className="mt-1.5 text-sm text-slate">Enter your 4-digit PIN to unlock OffPay.</p>

      <div className="mt-8 flex gap-3">
        {digits.map((d, i) => (
          <input
            key={i}
            id={`pin-${i}`}
            type="password"
            inputMode="numeric"
            maxLength={1}
            value={d}
            disabled={loading}
            onChange={(e) => updateDigit(i, e.target.value)}
            className="h-14 w-12 rounded-lg border border-line text-center text-2xl font-semibold focus:border-ink focus:outline-none"
          />
        ))}
      </div>

      {error && <div className="mt-5 w-full"><Alert type="error">{error}</Alert></div>}
      {loading && <p className="mt-4 text-sm text-slate">Checking…</p>}

      <button onClick={useDifferentAccount} className="mt-8 text-sm text-slate underline">
        Not you? Log in with a different account
      </button>
    </section>
  );
}

export default function UnlockPage() {
  return (
    <Suspense fallback={null}>
      <UnlockForm />
    </Suspense>
  );
}
