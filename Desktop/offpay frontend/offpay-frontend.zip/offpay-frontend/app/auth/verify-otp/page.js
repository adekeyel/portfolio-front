'use client';
import { Suspense, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import MarketingNav from '../../../components/MarketingNav';
import Input from '../../../components/Input';
import Button from '../../../components/Button';
import Alert from '../../../components/Alert';
import { apiFetch, setAccessToken, setRefreshToken, setUnlockedThisSession } from '../../../lib/api';

function VerifyOtpForm() {
  const router = useRouter();
  const params = useSearchParams();
  const userId = params.get('userId');
  const deviceId = params.get('deviceId');
  const email = params.get('email');

  const [code, setCode] = useState('');
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      // This is the ONE and only OTP step in the whole app — it proves the
      // email is real at signup. It also logs the user straight in, since
      // password + email are both verified at this point already.
      const res = await apiFetch('/auth/verify-email-otp', { method: 'POST', body: { userId, code, deviceId } });
      setAccessToken(res.data.accessToken);
      setRefreshToken(res.data.refreshToken);
      setUnlockedThisSession(true);
      router.push(res.data.appLockPinSet ? '/dashboard' : '/auth/set-pin');
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <section className="mx-auto max-w-md px-6 py-20">
      <h1 className="font-display text-3xl text-ink">Enter your code</h1>
      <p className="mt-2 text-sm text-slate">
        We sent a 6-digit code to {email || 'your registered email'}. It expires in 10 minutes.
        This is the only time you'll ever need a code — after this, you unlock OffPay with a PIN.
      </p>
      <form onSubmit={submit} className="mt-8 space-y-4">
        <Input label="Verification code" required maxLength={6} inputMode="numeric" value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))} />
        {error && <Alert type="error">{error}</Alert>}
        <Button type="submit" className="w-full" disabled={loading}>{loading ? 'Verifying…' : 'Verify'}</Button>
      </form>
    </section>
  );
}

export default function VerifyOtpPage() {
  return (
    <div>
      <MarketingNav />
      <Suspense fallback={null}>
        <VerifyOtpForm />
      </Suspense>
    </div>
  );
}
