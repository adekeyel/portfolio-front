'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Button from '../../../components/Button';
import Alert from '../../../components/Alert';
import { apiFetch, setUnlockedThisSession } from '../../../lib/api';

export default function SetPinPage() {
  const router = useRouter();
  const [pin, setPin] = useState('');
  const [confirm, setConfirm] = useState('');
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setError(null);
    if (!/^\d{4}$/.test(pin)) return setError('PIN must be exactly 4 digits.');
    if (pin !== confirm) return setError('PINs don\u2019t match — try again.');

    setLoading(true);
    try {
      await apiFetch('/auth/set-app-lock-pin', { method: 'POST', body: { pin } });
      // Already have a fresh access token from registration verification, so
      // this device is unlocked for the rest of this session immediately.
      setUnlockedThisSession(true);
      router.push('/dashboard');
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <section className="mx-auto flex min-h-screen max-w-sm flex-col justify-center px-6">
      <h1 className="font-display text-3xl text-ink">Set your app-lock PIN</h1>
      <p className="mt-2 text-sm text-slate">
        This 4-digit PIN is separate from your password — you'll use it to quickly unlock OffPay
        each time you come back, instead of logging in from scratch.
      </p>

      <form onSubmit={submit} className="mt-8 space-y-4">
        <label className="block">
          <span className="mb-1.5 block text-sm font-medium text-ink">Choose a 4-digit PIN</span>
          <input
            type="password" inputMode="numeric" maxLength={4} required value={pin}
            onChange={(e) => setPin(e.target.value.replace(/\D/g, ''))}
            className="w-full rounded-lg border border-line px-3.5 py-2.5 text-center text-lg tracking-[0.5em]"
          />
        </label>
        <label className="block">
          <span className="mb-1.5 block text-sm font-medium text-ink">Confirm PIN</span>
          <input
            type="password" inputMode="numeric" maxLength={4} required value={confirm}
            onChange={(e) => setConfirm(e.target.value.replace(/\D/g, ''))}
            className="w-full rounded-lg border border-line px-3.5 py-2.5 text-center text-lg tracking-[0.5em]"
          />
        </label>
        {error && <Alert type="error">{error}</Alert>}
        <Button type="submit" className="w-full" disabled={loading}>{loading ? 'Saving…' : 'Set PIN & continue'}</Button>
      </form>
    </section>
  );
}
