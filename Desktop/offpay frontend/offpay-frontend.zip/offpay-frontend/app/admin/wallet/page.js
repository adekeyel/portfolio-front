'use client';
import { useState } from 'react';
import AdminShell from '../../../components/AdminShell';
import Alert from '../../../components/Alert';
import Button from '../../../components/Button';
import Input from '../../../components/Input';
import { adminFetch, getAdminInfo } from '../../../lib/adminApi';

export default function AdminWalletPage() {
  const [q, setQ] = useState('');
  const [results, setResults] = useState([]);
  const [selected, setSelected] = useState(null);
  const [history, setHistory] = useState([]);
  const [form, setForm] = useState({ direction: 'credit', amount: '', reason: '' });
  const [status, setStatus] = useState(null);
  const role = getAdminInfo()?.role;
  const canAdjust = role === 'admin';

  async function search(e) {
    e.preventDefault();
    try {
      const res = await adminFetch(`/admin/wallet/search?q=${encodeURIComponent(q)}`);
      setResults(res.data);
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    }
  }

  async function select(w) {
    setSelected(w);
    setStatus(null);
    try {
      const res = await adminFetch(`/admin/wallet/${w.wallet_id}/history`);
      setHistory(res.data);
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    }
  }

  async function submitAdjust(e) {
    e.preventDefault();
    if (!selected) return;
    try {
      await adminFetch(`/admin/wallet/${selected.wallet_id}/adjust`, {
        method: 'POST',
        body: { direction: form.direction, amount: parseFloat(form.amount), reason: form.reason },
      });
      setStatus({ type: 'success', text: `Wallet ${form.direction}ed successfully.` });
      setForm({ direction: 'credit', amount: '', reason: '' });
      select(selected);
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    }
  }

  return (
    <AdminShell>
      <h1 className="font-display text-2xl text-ink">Wallet</h1>
      <p className="mt-1 text-sm text-slate">Search a user's wallet by name, user ID, email, or account number.{!canAdjust && ' Only super admin can post manual credits/debits — you have view access.'}</p>

      <form onSubmit={search} className="mt-4 flex max-w-lg gap-2">
        <Input placeholder="Name, user ID, email, or account number" value={q} onChange={(e) => setQ(e.target.value)} />
        <Button type="submit">Search</Button>
      </form>

      {status && <div className="mt-4"><Alert type={status.type}>{status.text}</Alert></div>}

      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <div className="rounded-xl2 border border-line bg-white shadow-card">
          {results.map((w) => (
            <button
              key={w.wallet_id}
              onClick={() => select(w)}
              className={`flex w-full items-center justify-between border-b border-line px-5 py-3.5 text-left last:border-0 hover:bg-paper ${selected?.wallet_id === w.wallet_id ? 'bg-paper' : ''}`}
            >
              <div>
                <p className="text-sm font-medium text-ink">{w.full_name}</p>
                <p className="text-xs text-slate">{w.email} · {w.wallet_ref} · {w.virtual_account}</p>
              </div>
              <p className="font-mono text-sm">₦{Number(w.balance).toLocaleString()}</p>
            </button>
          ))}
          {results.length === 0 && <p className="p-6 text-center text-sm text-slate">Search to find a wallet.</p>}
        </div>

        {selected && (
          <div className="space-y-6">
            <div className="rounded-xl2 border border-line bg-white p-6 shadow-card">
              <p className="font-display text-lg text-ink">{selected.full_name}</p>
              <p className="text-sm text-slate">{selected.wallet_ref} · {selected.virtual_account}</p>
              <p className="mt-2 font-mono text-2xl font-semibold text-ink">₦{Number(selected.balance).toLocaleString()}</p>
              {selected.is_frozen && <p className="mt-1 text-xs font-medium text-danger">This wallet is frozen.</p>}

              {canAdjust && (
                <form onSubmit={submitAdjust} className="mt-5 space-y-3 border-t border-line pt-5">
                  <p className="text-sm font-medium text-ink">Manual adjustment</p>
                  <div className="flex gap-2">
                    <select value={form.direction} onChange={(e) => setForm({ ...form, direction: e.target.value })} className="rounded-lg border border-line px-3 py-2.5 text-sm">
                      <option value="credit">Credit (add funds)</option>
                      <option value="debit">Debit (remove funds)</option>
                    </select>
                    <Input type="number" min="1" step="0.01" placeholder="Amount (₦)" required value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} />
                  </div>
                  <textarea placeholder="Reason (required, goes into the audit log)" required value={form.reason} onChange={(e) => setForm({ ...form, reason: e.target.value })} className="w-full rounded-lg border border-line px-3 py-2 text-sm" rows={2} />
                  <Button type="submit" variant={form.direction === 'debit' ? 'danger' : 'accent'}>{form.direction === 'debit' ? 'Debit wallet' : 'Credit wallet'}</Button>
                </form>
              )}
            </div>

            <div className="rounded-xl2 border border-line bg-white p-6 shadow-card">
              <p className="text-xs font-semibold uppercase tracking-wide text-slate">Recent transactions</p>
              <div className="mt-3 space-y-2">
                {history.map((t) => (
                  <div key={t.id} className="flex items-center justify-between rounded-lg bg-paper px-3 py-2 text-xs">
                    <div>
                      <p className="font-medium text-ink">{t.narration}</p>
                      <p className="text-slate">{t.reference} · {new Date(t.created_at).toLocaleString('en-NG')}</p>
                    </div>
                    <p className={`font-mono ${t.direction === 'credit' ? 'text-unlock' : 'text-ink'}`}>{t.direction === 'credit' ? '+' : '−'}₦{Number(t.amount).toLocaleString()}</p>
                  </div>
                ))}
                {history.length === 0 && <p className="text-xs text-slate">No transactions yet.</p>}
              </div>
            </div>
          </div>
        )}
      </div>
    </AdminShell>
  );
}
