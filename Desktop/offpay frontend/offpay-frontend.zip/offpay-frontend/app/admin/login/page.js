'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Input from '../../../components/Input';
import Button from '../../../components/Button';
import Alert from '../../../components/Alert';
import { adminFetch, setAdminToken, setAdminInfo } from '../../../lib/adminApi';

export default function AdminLoginPage() {
  const router = useRouter();
  const [step, setStep] = useState('credentials'); // 'credentials' | 'otp'
  const [form, setForm] = useState({ email: '', password: '', code: '' });
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  async function submitCredentials(e) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      await adminFetch('/admin/auth/login', { method: 'POST', body: { email: form.email, password: form.password } });
      setStep('otp');
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  async function submitOtp(e) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await adminFetch('/admin/auth/verify-otp', { method: 'POST', body: { email: form.email, code: form.code } });
      setAdminToken(res.data.accessToken);
      setAdminInfo(res.data.admin);
      router.push('/admin/dashboard');
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-ink px-6">
      <div className="w-full max-w-sm rounded-xl2 bg-white p-8 shadow-card">
        <p className="font-display text-xl text-ink">Off<span className="text-unlock">Pay</span> Admin</p>
        <p className="mt-1 text-sm text-slate">Internal access only.</p>

        {step === 'credentials' ? (
          <form onSubmit={submitCredentials} className="mt-6 space-y-4">
            <Input label="Email" type="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
            <Input label="Password" type="password" required value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
            {error && <Alert type="error">{error}</Alert>}
            <Button type="submit" className="w-full" disabled={loading}>{loading ? 'Checking…' : 'Continue'}</Button>
          </form>
        ) : (
          <form onSubmit={submitOtp} className="mt-6 space-y-4">
            <p className="text-sm text-slate">Enter the code sent to {form.email}.</p>
            <Input label="OTP code" required maxLength={6} value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value.replace(/\D/g, '') })} />
            {error && <Alert type="error">{error}</Alert>}
            <Button type="submit" className="w-full" disabled={loading}>{loading ? 'Verifying…' : 'Log in'}</Button>
          </form>
        )}
      </div>
    </div>
  );
}
