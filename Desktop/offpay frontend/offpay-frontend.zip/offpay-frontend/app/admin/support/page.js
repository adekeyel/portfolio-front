'use client';
import { useEffect, useState } from 'react';
import AdminShell from '../../../components/AdminShell';
import Alert from '../../../components/Alert';
import Button from '../../../components/Button';
import { adminFetch } from '../../../lib/adminApi';

const STATUSES = ['open', 'in_progress', 'resolved', 'closed'];

export default function AdminSupportPage() {
  const [tab, setTab] = useState('tickets');
  const [tickets, setTickets] = useState([]);
  const [statusFilter, setStatusFilter] = useState('open');
  const [replyText, setReplyText] = useState({});
  const [replyStatus, setReplyStatus] = useState({});
  const [status, setStatus] = useState(null);
  const [openId, setOpenId] = useState(null);
  const [thread, setThread] = useState(null);

  useEffect(() => { if (tab === 'tickets') load(); }, [tab, statusFilter]);

  // Light polling so a new user reply shows up without the agent needing to
  // know to refresh — mirrors the same pattern already used client-side.
  useEffect(() => {
    if (tab !== 'tickets') return;
    const timer = setInterval(load, 20000);
    return () => clearInterval(timer);
  }, [tab, statusFilter]);

  async function load() {
    try {
      const res = await adminFetch(`/admin/support/tickets?status=${statusFilter}`);
      setTickets(res.data);
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    }
  }

  async function openTicket(id) {
    if (openId === id) { setOpenId(null); setThread(null); return; }
    setOpenId(id);
    setThread(null);
    try {
      const res = await adminFetch(`/admin/support/tickets/${id}`);
      setThread(res.data);
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    }
  }

  async function reply(id) {
    try {
      await adminFetch(`/admin/support/tickets/${id}/reply`, {
        method: 'POST',
        body: { message: replyText[id], status: replyStatus[id] || 'in_progress' },
      });
      setStatus({ type: 'success', text: 'Reply sent.' });
      setReplyText({ ...replyText, [id]: '' });
      await load();
      if (openId === id) {
        const res = await adminFetch(`/admin/support/tickets/${id}`);
        setThread(res.data);
      }
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    }
  }

  return (
    <AdminShell>
      <h1 className="font-display text-2xl text-ink">Support</h1>
      <p className="mt-1 text-sm text-slate">Where the support team handles tickets, live chat, and other user queries.</p>

      <div className="mt-4 flex gap-2 border-b border-line">
        {['tickets', 'live-chat'].map((t) => (
          <button key={t} onClick={() => setTab(t)} className={`px-4 py-2 text-sm font-medium ${tab === t ? 'border-b-2 border-ink text-ink' : 'text-slate'}`}>
            {t === 'tickets' ? 'Tickets' : 'Live chat'}
          </button>
        ))}
      </div>

      {status && <div className="mt-4"><Alert type={status.type}>{status.text}</Alert></div>}

      {tab === 'tickets' ? (
        <>
          <div className="mt-4">
            <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="rounded-lg border border-line bg-white px-3 py-2.5 text-sm">
              {STATUSES.map((s) => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}
            </select>
          </div>
          <div className="mt-6 space-y-4">
            {tickets.map((t) => (
              <div key={t.id} className="rounded-xl2 border border-line bg-white p-6 shadow-card">
                <button className="flex w-full items-center justify-between text-left" onClick={() => openTicket(t.id)}>
                  <div>
                    <p className="font-display text-lg text-ink">{t.subject}</p>
                    {t.last_reply_message && (
                      <p className="mt-1 text-xs text-slate">
                        Last: <span className={t.last_reply_author_type === 'user' ? 'font-semibold text-ink' : ''}>
                          {t.last_reply_author_type === 'user' ? 'User' : 'Support'} — {t.last_reply_message.slice(0, 80)}
                        </span>
                      </p>
                    )}
                  </div>
                  <span className="rounded-full bg-paper px-2.5 py-0.5 text-xs font-medium capitalize">{t.status}</span>
                </button>

                {openId === t.id && (
                  <div className="mt-4 border-t border-line pt-4">
                    {!thread ? (
                      <p className="text-sm text-slate">Loading conversation…</p>
                    ) : (
                      <div className="space-y-3">
                        <div className="rounded-lg bg-paper p-3">
                          <p className="text-xs font-semibold text-slate">User (original message)</p>
                          <p className="mt-1 whitespace-pre-wrap text-sm text-ink">{thread.ticket.message}</p>
                        </div>
                        {thread.replies.map((r) => (
                          <div key={r.id} className={`rounded-lg p-3 ${r.author_type === 'user' ? 'bg-paper' : 'bg-unlock/10'}`}>
                            <p className="text-xs font-semibold text-slate">{r.author_type === 'user' ? 'User' : 'Support'} · {new Date(r.created_at).toLocaleString('en-NG')}</p>
                            <p className="mt-1 whitespace-pre-wrap text-sm text-ink">{r.message}</p>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                {t.status !== 'closed' && (
                  <div className="mt-4 space-y-2">
                    <textarea value={replyText[t.id] || ''} onChange={(e) => setReplyText({ ...replyText, [t.id]: e.target.value })} placeholder="Type a reply…" className="w-full rounded-lg border border-line px-3 py-2 text-sm" rows={2} />
                    <div className="flex flex-wrap items-center gap-2">
                      <select value={replyStatus[t.id] || 'in_progress'} onChange={(e) => setReplyStatus({ ...replyStatus, [t.id]: e.target.value })} className="rounded-lg border border-line px-3 py-2 text-xs">
                        {STATUSES.map((s) => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}
                      </select>
                      <Button variant="ghost" onClick={() => reply(t.id)}>Send reply</Button>
                    </div>
                  </div>
                )}
              </div>
            ))}
            {tickets.length === 0 && <p className="rounded-xl2 border border-line bg-white p-6 text-center text-sm text-slate shadow-card">No tickets here.</p>}
          </div>
        </>
      ) : (
        <div className="mt-6 rounded-xl2 border border-line bg-white p-8 text-center shadow-card">
          <p className="font-display text-lg text-ink">Live chat</p>
          <p className="mx-auto mt-2 max-w-md text-sm text-slate">
            Ticket handling is fully wired up above. Live chat needs a realtime layer (WebSocket/Socket.io) between the user app and
            this dashboard, which isn't in this build yet — happy to wire it up as the next piece if you want it.
          </p>
        </div>
      )}
    </AdminShell>
  );
}
