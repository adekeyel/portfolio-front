'use client';
import { useEffect, useState } from 'react';
import AdminShell from '../../../components/AdminShell';
import Alert from '../../../components/Alert';
import { adminFetch } from '../../../lib/adminApi';

const STATUSES = ['open', 'reviewing', 'resolved', 'false_positive', 'all'];
const SEVERITY_STYLE = { low: 'bg-slate-100 text-slate', medium: 'bg-amber-50 text-amber-700', high: 'bg-orange-50 text-orange-700', critical: 'bg-red-50 text-danger' };

export default function AdminFraudPage() {
  const [alerts, setAlerts] = useState([]);
  const [statusFilter, setStatusFilter] = useState('open');
  const [status, setStatus] = useState(null);
  const [notesById, setNotesById] = useState({});

  useEffect(() => { load(); }, [statusFilter]);

  async function load() {
    try {
      const res = await adminFetch(`/admin/fraud-alerts?status=${statusFilter}`);
      setAlerts(res.data);
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    }
  }

  async function act(id, action) {
    try {
      await adminFetch(`/admin/fraud-alerts/${id}/action`, { method: 'POST', body: { action, notes: notesById[id] || '' } });
      setStatus({ type: 'success', text: 'Action recorded.' });
      load();
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    }
  }

  return (
    <AdminShell>
      <h1 className="font-display text-2xl text-ink">Fraud monitoring</h1>
      <p className="mt-1 text-sm text-slate">Transactions are auto-flagged for unusually large amounts or rapid-fire activity from one wallet.</p>

      <div className="mt-4">
        <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="rounded-lg border border-line bg-white px-3 py-2.5 text-sm">
          {STATUSES.map((s) => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}
        </select>
      </div>
      {status && <div className="mt-4"><Alert type={status.type}>{status.text}</Alert></div>}

      <div className="mt-6 space-y-4">
        {alerts.map((a) => (
          <div key={a.id} className="rounded-xl2 border border-line bg-white p-5 shadow-card">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${SEVERITY_STYLE[a.severity] || 'bg-slate-100 text-slate'}`}>{a.severity}</span>
                  <span className="text-xs font-mono text-slate">{a.rule_code}</span>
                </div>
                <p className="mt-1.5 text-sm font-medium text-ink">{a.full_name || 'Unknown user'} — {a.email}</p>
                <p className="mt-1 text-sm text-slate">{a.reason}</p>
                {a.reference && <p className="mt-1 text-xs font-mono text-slate">{a.reference} · ₦{Number(a.amount).toLocaleString()} · {new Date(a.txn_time).toLocaleString('en-NG')}</p>}
              </div>
              <span className="rounded-full bg-paper px-2.5 py-1 text-xs font-medium text-ink">{a.status}</span>
            </div>

            {a.status === 'open' || a.status === 'reviewing' ? (
              <div className="mt-4 space-y-2 border-t border-line pt-4">
                <textarea placeholder="Notes (optional)" value={notesById[a.id] || ''} onChange={(e) => setNotesById({ ...notesById, [a.id]: e.target.value })} className="w-full rounded-lg border border-line px-3 py-2 text-sm" rows={2} />
                <div className="flex flex-wrap gap-2">
                  <button onClick={() => act(a.id, 'freeze_wallet')} className="rounded-lg border border-line px-3 py-1.5 text-xs font-medium hover:bg-paper">Freeze wallet</button>
                  <button onClick={() => act(a.id, 'block_user')} className="rounded-lg border border-line px-3 py-1.5 text-xs font-medium text-danger hover:bg-red-50">Block user</button>
                  <button onClick={() => act(a.id, 'mark_reviewing')} className="rounded-lg border border-line px-3 py-1.5 text-xs font-medium hover:bg-paper">Mark reviewing</button>
                  <button onClick={() => act(a.id, 'resolve')} className="rounded-lg border border-line px-3 py-1.5 text-xs font-medium text-unlock hover:bg-unlock-dim">Resolve</button>
                  <button onClick={() => act(a.id, 'dismiss')} className="rounded-lg border border-line px-3 py-1.5 text-xs font-medium text-slate hover:bg-paper">Dismiss (false positive)</button>
                </div>
              </div>
            ) : (
              a.notes && <p className="mt-3 border-t border-line pt-3 text-xs text-slate">Notes: {a.notes}</p>
            )}
          </div>
        ))}
        {alerts.length === 0 && <p className="rounded-xl2 border border-line bg-white p-6 text-center text-sm text-slate shadow-card">No alerts here.</p>}
      </div>
    </AdminShell>
  );
}
