'use client';
import { useEffect, useState } from 'react';
import AdminShell from '../../../components/AdminShell';
import Alert from '../../../components/Alert';
import Input from '../../../components/Input';
import { adminFetch } from '../../../lib/adminApi';

export default function ClosedAccountsPage() {
  const [users, setUsers] = useState([]);
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState(null);

  useEffect(() => { load(); }, [search]);

  async function load() {
    try {
      const params = new URLSearchParams({ filter: 'closed' });
      if (search) params.set('search', search);
      const res = await adminFetch(`/admin/users?${params.toString()}`);
      setUsers(res.data);
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    }
  }

  return (
    <AdminShell>
      <h1 className="font-display text-2xl text-ink">Closed accounts</h1>
      <p className="mt-1 text-sm text-slate">Accounts that have been closed. Use Accounts → Close to close, or reverse from the account's action history.</p>
      <div className="mt-4 max-w-sm">
        <Input placeholder="Search by name, email, or phone" value={search} onChange={(e) => setSearch(e.target.value)} />
      </div>
      {status && <div className="mt-4"><Alert type={status.type}>{status.text}</Alert></div>}

      <div className="mt-6 overflow-x-auto rounded-xl2 border border-line bg-white shadow-card">
        <table className="w-full text-sm">
          <thead className="bg-paper text-left text-xs uppercase tracking-wide text-slate">
            <tr>
              <th className="px-4 py-3">User</th>
              <th className="px-4 py-3">Contact</th>
              <th className="px-4 py-3">Wallet</th>
              <th className="px-4 py-3">Closed since</th>
            </tr>
          </thead>
          <tbody>
            {users.map((u) => (
              <tr key={u.id} className="border-t border-line">
                <td className="px-4 py-3 font-medium text-ink">{u.full_name}</td>
                <td className="px-4 py-3 text-slate">{u.email}<br /><span className="text-xs">{u.phone}</span></td>
                <td className="px-4 py-3 font-mono text-xs">{u.wallet_id || '—'}</td>
                <td className="px-4 py-3 text-slate">{new Date(u.created_at).toLocaleDateString('en-NG')}</td>
              </tr>
            ))}
            {users.length === 0 && <tr><td colSpan={4} className="p-6 text-center text-sm text-slate">No closed accounts.</td></tr>}
          </tbody>
        </table>
      </div>
    </AdminShell>
  );
}
