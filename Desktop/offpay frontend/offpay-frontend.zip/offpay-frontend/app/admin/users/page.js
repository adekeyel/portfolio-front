'use client';
import { useEffect, useState } from 'react';
import AdminShell from '../../../components/AdminShell';
import Alert from '../../../components/Alert';
import Button from '../../../components/Button';
import Input from '../../../components/Input';
import { adminFetch, getAdminInfo } from '../../../lib/adminApi';
import { resolveMediaUrl } from '../../../lib/media';

function age(dob) {
  if (!dob) return null;
  const d = new Date(dob);
  if (Number.isNaN(d.getTime())) return null;
  const diff = Date.now() - d.getTime();
  return Math.floor(diff / (365.25 * 24 * 60 * 60 * 1000));
}

const FILTERS = [
  { value: 'all', label: 'All' },
  { value: 'active', label: 'Active' },
  { value: 'frozen', label: 'Frozen' },
  { value: 'suspended', label: 'Suspended' },
  { value: 'signup', label: 'Signup' },
  { value: 'signup_rejected', label: 'Signup rejected' },
  { value: 'kyc_pending', label: 'KYC pending' },
  { value: 'kyc_approved', label: 'KYC approved' },
];

const STATUS_STYLE = {
  active: 'bg-unlock-dim text-unlock',
  frozen: 'bg-blue-50 text-blue-700',
  suspended: 'bg-lock-dim text-ink',
  closed: 'bg-slate-100 text-slate',
  blocked: 'bg-red-50 text-danger',
  deleted: 'bg-slate-100 text-slate',
  pending_kyc: 'bg-amber-50 text-amber-700',
};

export default function AdminUsersPage() {
  const [users, setUsers] = useState([]);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('all');
  const [selected, setSelected] = useState(null);
  const [detail, setDetail] = useState(null);
  const [status, setStatus] = useState(null);
  const [reasonModal, setReasonModal] = useState(null); // { action, userId }
  const [reason, setReason] = useState('');
  const role = getAdminInfo()?.role;
  const canAct = role === 'admin' || role === 'compliance';

  useEffect(() => { load(); }, [search, filter]);

  async function load() {
    try {
      const params = new URLSearchParams();
      if (search) params.set('search', search);
      if (filter && filter !== 'all') params.set('filter', filter);
      const res = await adminFetch(`/admin/users?${params.toString()}`);
      setUsers(res.data);
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    }
  }

  async function openDetail(id) {
    setSelected(id);
    try {
      const res = await adminFetch(`/admin/users/${id}`);
      setDetail(res.data);
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    }
  }

  async function confirmAction() {
    try {
      await adminFetch(`/admin/users/${reasonModal.userId}/actions/${reasonModal.action}`, { method: 'POST', body: { reason } });
      setStatus({ type: 'success', text: `Account ${reasonModal.action}ed.` });
      setReasonModal(null);
      setReason('');
      load();
      openDetail(reasonModal.userId);
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    }
  }

  async function reverse(actionId) {
    try {
      await adminFetch(`/admin/users/${selected}/actions/${actionId}/reverse`, { method: 'POST' });
      setStatus({ type: 'success', text: 'Action reversed.' });
      openDetail(selected);
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    }
  }

  return (
    <AdminShell>
      <h1 className="font-display text-2xl text-ink">Accounts</h1>
      <div className="mt-4 flex flex-wrap items-end gap-3">
        <div className="max-w-sm flex-1">
          <Input placeholder="Search by name, email, or phone number" value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <label className="block">
          <span className="mb-1.5 block text-xs font-medium text-slate">Filter</span>
          <select value={filter} onChange={(e) => setFilter(e.target.value)} className="rounded-lg border border-line bg-white px-3 py-2.5 text-sm">
            {FILTERS.map((f) => <option key={f.value} value={f.value}>{f.label}</option>)}
          </select>
        </label>
      </div>
      {status && <div className="mt-4"><Alert type={status.type}>{status.text}</Alert></div>}

      <div className="mt-6 grid gap-6 lg:grid-cols-5">
        <div className="overflow-x-auto rounded-xl2 border border-line bg-white shadow-card lg:col-span-3">
          <table className="w-full text-sm">
            <thead className="bg-paper text-left text-xs uppercase tracking-wide text-slate">
              <tr>
                <th className="px-4 py-3">User</th>
                <th className="px-4 py-3">Contact</th>
                <th className="px-4 py-3">Wallet</th>
                <th className="px-4 py-3">Tier</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3">Joined</th>
              </tr>
            </thead>
            <tbody>
              {users.map((u) => (
                <tr
                  key={u.id}
                  onClick={() => openDetail(u.id)}
                  className={`cursor-pointer border-t border-line hover:bg-paper ${selected === u.id ? 'bg-paper' : ''}`}
                >
                  <td className="px-4 py-3 font-medium text-ink">{u.full_name}</td>
                  <td className="px-4 py-3 text-slate">
                    <p>{u.email}</p>
                    <p className="text-xs">{u.phone}</p>
                  </td>
                  <td className="px-4 py-3 font-mono text-xs">
                    <p>{u.wallet_id || '—'}</p>
                    <p className="text-slate">₦{Number(u.balance || 0).toLocaleString()}</p>
                  </td>
                  <td className="px-4 py-3">Tier {u.kyc_tier}</td>
                  <td className="px-4 py-3">
                    <span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${STATUS_STYLE[u.status] || 'bg-slate-100 text-slate'}`}>{u.status}</span>
                  </td>
                  <td className="px-4 py-3 text-slate">{new Date(u.created_at).toLocaleDateString('en-NG')}</td>
                </tr>
              ))}
              {users.length === 0 && (
                <tr><td colSpan={6} className="p-6 text-center text-sm text-slate">No users found.</td></tr>
              )}
            </tbody>
          </table>
        </div>

        {detail && (
          <div className="rounded-xl2 border border-line bg-white p-6 shadow-card lg:col-span-2">
            <p className="font-display text-lg text-ink">{detail.full_name}</p>
            <p className="text-sm text-slate">{detail.email} · {detail.phone}</p>
            <dl className="mt-4 space-y-1.5 text-sm">
              <div className="flex justify-between"><dt className="text-slate">Status</dt><dd className="font-medium">{detail.status}</dd></div>
              <div className="flex justify-between"><dt className="text-slate">KYC</dt><dd className="font-medium">{detail.kyc_status} · Tier {detail.kyc_tier}</dd></div>
              {detail.tier_upgrade_status && (
                <div className="flex justify-between"><dt className="text-slate">Tier upgrade</dt><dd className="font-medium capitalize">{detail.tier_upgrade_status}</dd></div>
              )}
              <div className="flex justify-between"><dt className="text-slate">Sex</dt><dd className="font-medium capitalize">{detail.sex || '—'}</dd></div>
              <div className="flex justify-between">
                <dt className="text-slate">Date of birth</dt>
                <dd className="font-medium">{detail.date_of_birth ? `${new Date(detail.date_of_birth).toLocaleDateString('en-NG')} (${age(detail.date_of_birth)})` : '—'}</dd>
              </div>
              <div className="flex justify-between"><dt className="text-slate">Address</dt><dd className="max-w-[60%] text-right font-medium">{detail.address || '—'}</dd></div>
              <div className="flex justify-between"><dt className="text-slate">BVN</dt><dd className="font-mono">{detail.bvn || '—'}</dd></div>
              <div className="flex justify-between"><dt className="text-slate">NIN</dt><dd className="font-mono">{detail.nin || '—'}</dd></div>
              <div className="flex justify-between"><dt className="text-slate">OffPay account ID</dt><dd className="font-mono">{detail.wallet_id}</dd></div>
              <div className="flex justify-between">
                <dt className="text-slate">Virtual account</dt>
                <dd className="font-mono">{detail.virtual_account ? `${detail.virtual_account} (${detail.virtual_bank})` : '—'}</dd>
              </div>
              <div className="flex justify-between"><dt className="text-slate">Balance</dt><dd className="font-mono">₦{Number(detail.balance || 0).toLocaleString()}</dd></div>
              <div className="flex justify-between"><dt className="text-slate">Frozen</dt><dd className="font-medium">{detail.is_frozen ? 'Yes' : 'No'}</dd></div>
            </dl>

            {(detail.passport_url || detail.nin_slip_url || detail.utility_bill_url) && (
              <div className="mt-5">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate">Submitted documents</p>
                <div className="mt-2 flex flex-wrap gap-3">
                  {detail.passport_url && (
                    <a href={resolveMediaUrl(detail.passport_url)} target="_blank" rel="noreferrer" className="block">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={resolveMediaUrl(detail.passport_url)} alt="Passport" className="h-20 w-20 rounded-lg border border-line object-cover" />
                      <p className="mt-1 text-center text-[11px] text-slate">Passport</p>
                    </a>
                  )}
                  {detail.nin_slip_url && (
                    <a href={resolveMediaUrl(detail.nin_slip_url)} target="_blank" rel="noreferrer" className="block">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={resolveMediaUrl(detail.nin_slip_url)} alt="NIN slip" className="h-20 w-20 rounded-lg border border-line object-cover" />
                      <p className="mt-1 text-center text-[11px] text-slate">NIN slip</p>
                    </a>
                  )}
                  {detail.utility_bill_url && (
                    <a href={resolveMediaUrl(detail.utility_bill_url)} target="_blank" rel="noreferrer" className="block">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={resolveMediaUrl(detail.utility_bill_url)} alt="Utility bill" className="h-20 w-20 rounded-lg border border-line object-cover" />
                      <p className="mt-1 text-center text-[11px] text-slate">Utility bill</p>
                    </a>
                  )}
                </div>
              </div>
            )}

            {canAct && (
              <div className="mt-5 flex flex-wrap gap-2">
                {['block', 'freeze', 'suspend', 'close', 'delete'].map((a) => (
                  <Button key={a} variant="ghost" onClick={() => setReasonModal({ action: a, userId: detail.id })}>{a[0].toUpperCase() + a.slice(1)}</Button>
                ))}
              </div>
            )}

            {reasonModal && (
              <div className="mt-4 space-y-2 rounded-lg border border-line bg-paper p-4">
                <p className="text-sm font-medium text-ink">Reason to {reasonModal.action} this account:</p>
                <textarea value={reason} onChange={(e) => setReason(e.target.value)} className="w-full rounded-lg border border-line px-3 py-2 text-sm" rows={2} />
                <div className="flex gap-2">
                  <Button variant="danger" onClick={confirmAction}>Confirm</Button>
                  <Button variant="ghost" onClick={() => setReasonModal(null)}>Cancel</Button>
                </div>
              </div>
            )}

            {detail.accountActions?.length > 0 && (
              <div className="mt-6">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate">Action history</p>
                <div className="mt-2 space-y-2">
                  {detail.accountActions.map((a) => (
                    <div key={a.id} className="flex items-center justify-between rounded-lg bg-paper px-3 py-2 text-xs">
                      <div>
                        <p className="font-medium text-ink">{a.action} — {a.reason}</p>
                        <p className="text-slate">by {a.performed_by_name} · {new Date(a.created_at).toLocaleDateString('en-NG')}{a.reversed ? ' · reversed' : ''}</p>
                      </div>
                      {!a.reversed && canAct && <button onClick={() => reverse(a.id)} className="font-medium text-unlock underline">Reverse</button>}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </AdminShell>
  );
}
