'use client';
import { useEffect, useState } from 'react';
import AdminShell from '../../../components/AdminShell';
import Alert from '../../../components/Alert';
import { adminFetch, getAdminInfo } from '../../../lib/adminApi';

const ROLES = ['admin', 'support', 'compliance', 'finance', 'operations', 'fraud', 'recovery'];

export default function StaffPage() {
  const [staff, setStaff] = useState([]);
  const [status, setStatus] = useState(null);
  const me = getAdminInfo();

  useEffect(() => { load(); }, []);

  async function load() {
    try {
      const res = await adminFetch('/admin/staff');
      setStaff(res.data);
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    }
  }

  async function changeRole(id, role) {
    try {
      await adminFetch(`/admin/staff/${id}/role`, { method: 'PATCH', body: { role } });
      setStatus({ type: 'success', text: 'Role updated.' });
      load();
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    }
  }

  async function toggleStatus(id, currentStatus) {
    const next = currentStatus === 'active' ? 'suspended' : 'active';
    try {
      await adminFetch(`/admin/staff/${id}/status`, { method: 'PATCH', body: { status: next } });
      setStatus({ type: 'success', text: `Account ${next}.` });
      load();
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    }
  }

  return (
    <AdminShell>
      <h1 className="font-display text-2xl text-ink">Staff</h1>
      <p className="mt-1 text-sm text-slate">Every admin account, their role and email — assign roles and manage access here. Create new accounts under Create users.</p>
      {status && <div className="mt-4"><Alert type={status.type}>{status.text}</Alert></div>}

      <div className="mt-6 overflow-x-auto rounded-xl2 border border-line bg-white shadow-card">
        <table className="w-full text-sm">
          <thead className="bg-paper text-left text-xs uppercase tracking-wide text-slate">
            <tr>
              <th className="px-4 py-3">Name</th>
              <th className="px-4 py-3">Email</th>
              <th className="px-4 py-3">Role</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3">Last login</th>
              <th className="px-4 py-3"></th>
            </tr>
          </thead>
          <tbody>
            {staff.map((s) => (
              <tr key={s.id} className="border-t border-line">
                <td className="px-4 py-3 font-medium text-ink">{s.full_name}</td>
                <td className="px-4 py-3 text-slate">{s.email}</td>
                <td className="px-4 py-3">
                  <select value={s.role} onChange={(e) => changeRole(s.id, e.target.value)} className="rounded-lg border border-line px-2 py-1.5 text-xs">
                    {ROLES.map((r) => <option key={r} value={r}>{r}</option>)}
                  </select>
                </td>
                <td className="px-4 py-3">
                  <span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${s.status === 'active' ? 'bg-unlock-dim text-unlock' : 'bg-red-50 text-danger'}`}>{s.status}</span>
                </td>
                <td className="px-4 py-3 text-slate">{s.last_login_at ? new Date(s.last_login_at).toLocaleDateString('en-NG') : 'Never'}</td>
                <td className="px-4 py-3">
                  {s.id !== me?.id && (
                    <button onClick={() => toggleStatus(s.id, s.status)} className="text-xs font-medium text-unlock underline">
                      {s.status === 'active' ? 'Suspend' : 'Reactivate'}
                    </button>
                  )}
                </td>
              </tr>
            ))}
            {staff.length === 0 && <tr><td colSpan={6} className="p-6 text-center text-sm text-slate">No staff accounts yet.</td></tr>}
          </tbody>
        </table>
      </div>
    </AdminShell>
  );
}
