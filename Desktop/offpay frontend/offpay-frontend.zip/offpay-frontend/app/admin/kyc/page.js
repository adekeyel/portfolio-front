'use client';
import { useEffect, useState } from 'react';
import AdminShell from '../../../components/AdminShell';
import Alert from '../../../components/Alert';
import Button from '../../../components/Button';
import { adminFetch } from '../../../lib/adminApi';
import { resolveMediaUrl } from '../../../lib/media';

export default function AdminKycPage() {
  const [pending, setPending] = useState([]);
  const [status, setStatus] = useState(null);
  const [rejectingId, setRejectingId] = useState(null);
  const [reason, setReason] = useState('');

  useEffect(() => { load(); }, []);

  async function load() {
    try {
      const res = await adminFetch('/admin/kyc/pending');
      setPending(res.data);
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    }
  }

  async function approve(id) {
    setStatus(null);
    try {
      await adminFetch(`/admin/kyc/${id}/approve`, { method: 'POST' });
      setStatus({ type: 'success', text: 'Approved and virtual account issued.' });
      load();
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    }
  }

  async function submitReject(id) {
    setStatus(null);
    try {
      await adminFetch(`/admin/kyc/${id}/reject`, { method: 'POST', body: { reason } });
      setStatus({ type: 'success', text: 'Rejected.' });
      setRejectingId(null);
      setReason('');
      load();
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    }
  }

  return (
    <AdminShell>
      <h1 className="font-display text-2xl text-ink">KYC review</h1>
      <p className="mt-1 text-sm text-slate">{pending.length} account(s) awaiting verification.</p>
      {status && <div className="mt-4"><Alert type={status.type}>{status.text}</Alert></div>}

      <div className="mt-6 space-y-4">
        {pending.map((u) => (
          <div key={u.id} className="rounded-xl2 border border-line bg-white p-6 shadow-card">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div>
                <p className="font-display text-lg text-ink">{u.full_name}</p>
                <p className="text-sm text-slate">{u.email} · {u.phone}</p>
                <p className="mt-1 font-mono text-sm text-ink">BVN: {u.bvn}</p>
                <p className="text-xs text-slate">Submitted {new Date(u.created_at).toLocaleString('en-NG')}</p>
              </div>
              <div className="flex gap-3">
                {u.passport_url && (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={resolveMediaUrl(u.passport_url)} alt="Passport" className="h-24 w-24 rounded-lg object-cover border border-line" />
                )}
                {u.nin_slip_url && (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={resolveMediaUrl(u.nin_slip_url)} alt="NIN slip" className="h-24 w-24 rounded-lg object-cover border border-line" />
                )}
                {u.utility_bill_url && (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={resolveMediaUrl(u.utility_bill_url)} alt="Utility bill" className="h-24 w-24 rounded-lg object-cover border border-line" />
                )}
              </div>
            </div>

            {rejectingId === u.id ? (
              <div className="mt-4 space-y-2">
                <textarea value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Reason for rejection" className="w-full rounded-lg border border-line px-3 py-2 text-sm" rows={2} />
                <div className="flex gap-2">
                  <Button variant="danger" onClick={() => submitReject(u.id)}>Confirm reject</Button>
                  <Button variant="ghost" onClick={() => setRejectingId(null)}>Cancel</Button>
                </div>
              </div>
            ) : (
              <div className="mt-4 flex gap-2">
                <Button onClick={() => approve(u.id)}>Approve & issue account</Button>
                <Button variant="ghost" onClick={() => setRejectingId(u.id)}>Reject</Button>
              </div>
            )}
          </div>
        ))}
        {pending.length === 0 && <p className="text-sm text-slate">No pending accounts. 🎉</p>}
      </div>
    </AdminShell>
  );
}
