'use client';
import { useEffect, useState } from 'react';
import AdminShell from '../../../components/AdminShell';
import Alert from '../../../components/Alert';
import Button from '../../../components/Button';
import Input from '../../../components/Input';
import { adminFetch, API_URL } from '../../../lib/adminApi';

const API_ORIGIN = API_URL.replace(/\/api\/?$/, '');
const PAGES = ['landing', 'dashboard', 'finance', 'cards'];
const POSITIONS = ['top', 'middle', 'bottom'];

export default function AdminAdsPage() {
  const [ads, setAds] = useState([]);
  const [status, setStatus] = useState(null);
  const [form, setForm] = useState({ title: '', targetPage: 'dashboard', position: 'middle', linkUrl: '', file: null });
  const [loading, setLoading] = useState(false);

  useEffect(() => { load(); }, []);

  async function load() {
    try {
      const res = await adminFetch('/admin/ads');
      setAds(res.data);
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    }
  }

  async function submit(e) {
    e.preventDefault();
    if (!form.file) return setStatus({ type: 'error', text: 'Choose an image or video file.' });
    setLoading(true);
    setStatus(null);
    try {
      const fd = new FormData();
      fd.append('title', form.title);
      fd.append('targetPage', form.targetPage);
      fd.append('position', form.position);
      if (form.linkUrl) fd.append('linkUrl', form.linkUrl);
      fd.append('media', form.file);
      await adminFetch('/admin/ads', { method: 'POST', body: fd, isForm: true });
      setStatus({ type: 'success', text: 'Ad created.' });
      setForm({ title: '', targetPage: 'dashboard', position: 'middle', linkUrl: '', file: null });
      load();
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    } finally {
      setLoading(false);
    }
  }

  async function toggleActive(ad) {
    try {
      await adminFetch(`/admin/ads/${ad.id}`, { method: 'PATCH', body: { active: !ad.active } });
      load();
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    }
  }

  async function remove(id) {
    try {
      await adminFetch(`/admin/ads/${id}`, { method: 'DELETE' });
      load();
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    }
  }

  // Flag when 2+ active ads share a page+position, so the admin can see rotation will kick in.
  const grouped = {};
  ads.filter((a) => a.active).forEach((a) => {
    const key = `${a.target_page}/${a.position}`;
    grouped[key] = (grouped[key] || 0) + 1;
  });

  return (
    <AdminShell>
      <h1 className="font-display text-2xl text-ink">Ads</h1>
      <p className="mt-1 text-sm text-slate">
        320×100 banner or short video ads, placed by page and position. When 2 or more active ads
        target the same page+position, the app rotates between them every 2 minutes.
      </p>
      {status && <div className="mt-4 max-w-lg"><Alert type={status.type}>{status.text}</Alert></div>}

      <form onSubmit={submit} className="mt-6 max-w-lg space-y-4 rounded-xl2 border border-line bg-white p-6 shadow-card">
        <p className="font-display text-lg text-ink">New ad</p>
        <Input label="Title" required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
        <div className="flex gap-3">
          <label className="block flex-1">
            <span className="mb-1.5 block text-sm font-medium text-ink">Page</span>
            <select value={form.targetPage} onChange={(e) => setForm({ ...form, targetPage: e.target.value })} className="w-full rounded-lg border border-line bg-white px-3.5 py-2.5 text-sm">
              {PAGES.map((p) => <option key={p} value={p}>{p}</option>)}
            </select>
          </label>
          <label className="block flex-1">
            <span className="mb-1.5 block text-sm font-medium text-ink">Position</span>
            <select value={form.position} onChange={(e) => setForm({ ...form, position: e.target.value })} className="w-full rounded-lg border border-line bg-white px-3.5 py-2.5 text-sm">
              {POSITIONS.map((p) => <option key={p} value={p}>{p}</option>)}
            </select>
          </label>
        </div>
        <Input label="Link URL (optional)" placeholder="https://…" value={form.linkUrl} onChange={(e) => setForm({ ...form, linkUrl: e.target.value })} />
        <label className="block">
          <span className="mb-1.5 block text-sm font-medium text-ink">Image or video (JPEG/PNG/WEBP/GIF/MP4/WEBM, up to 15MB)</span>
          <input type="file" accept="image/jpeg,image/png,image/webp,image/gif,video/mp4,video/webm" required
            onChange={(e) => setForm({ ...form, file: e.target.files[0] })}
            className="w-full rounded-lg border border-line px-3.5 py-2.5 text-sm" />
        </label>
        <Button type="submit" disabled={loading}>{loading ? 'Uploading…' : 'Create ad'}</Button>
      </form>

      <div className="mt-8 grid gap-4 sm:grid-cols-2">
        {ads.map((ad) => {
          const src = ad.media_url.startsWith('http') ? ad.media_url : `${API_ORIGIN}${ad.media_url}`;
          const sharesSlot = grouped[`${ad.target_page}/${ad.position}`] > 1;
          return (
            <div key={ad.id} className="rounded-xl2 border border-line bg-white p-4 shadow-card">
              <div className="flex h-[100px] w-[320px] max-w-full items-center justify-center overflow-hidden rounded-lg border border-line bg-paper">
                {ad.media_type === 'video'
                  ? <video src={src} className="h-full w-full object-cover" muted loop />
                  /* eslint-disable-next-line @next/next/no-img-element */
                  : <img src={src} alt={ad.title} className="h-full w-full object-cover" />}
              </div>
              <div className="mt-3 flex items-start justify-between gap-2">
                <div>
                  <p className="text-sm font-medium text-ink">{ad.title}</p>
                  <p className="text-xs text-slate">{ad.target_page} · {ad.position}{ad.active && sharesSlot ? ' · rotating (2 min)' : ''}</p>
                </div>
                <span className={`shrink-0 rounded-full px-2.5 py-0.5 text-xs font-medium ${ad.active ? 'bg-unlock-dim text-unlock' : 'bg-slate-100 text-slate'}`}>
                  {ad.active ? 'active' : 'inactive'}
                </span>
              </div>
              <div className="mt-3 flex gap-2">
                <button onClick={() => toggleActive(ad)} className="text-xs font-medium text-unlock underline">{ad.active ? 'Deactivate' : 'Activate'}</button>
                <button onClick={() => remove(ad.id)} className="text-xs font-medium text-danger underline">Delete</button>
              </div>
            </div>
          );
        })}
        {ads.length === 0 && <p className="text-sm text-slate">No ads yet.</p>}
      </div>
    </AdminShell>
  );
}
