'use client';
import { useEffect, useState } from 'react';
import AdminShell from '../../../components/AdminShell';
import Alert from '../../../components/Alert';
import Button from '../../../components/Button';
import Input from '../../../components/Input';
import { adminFetch, getAdminInfo } from '../../../lib/adminApi';

const ROLES = ['admin', 'support', 'compliance', 'finance', 'operations', 'fraud', 'recovery'];
const SEVERITY_STYLE = { info: 'bg-blue-50 text-blue-700', warning: 'bg-amber-50 text-amber-700', critical: 'bg-red-50 text-danger' };

export default function AdminNotificationsPage() {
  const [items, setItems] = useState([]);
  const [status, setStatus] = useState(null);
  const [form, setForm] = useState({ title: '', message: '', severity: 'info', targetRole: '' });
  const role = getAdminInfo()?.role;

  useEffect(() => { load(); }, []);

  async function load() {
    try {
      const res = await adminFetch('/admin/notifications');
      setItems(res.data);
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    }
  }

  async function markRead(id) {
    await adminFetch(`/admin/notifications/${id}/read`, { method: 'POST' }).catch(() => {});
    load();
  }

  async function broadcast(e) {
    e.preventDefault();
    try {
      await adminFetch('/admin/notifications', { method: 'POST', body: { ...form, targetRole: form.targetRole || undefined } });
      setStatus({ type: 'success', text: 'Notification sent.' });
      setForm({ title: '', message: '', severity: 'info', targetRole: '' });
      load();
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    }
  }

  return (
    <AdminShell>
      <h1 className="font-display text-2xl text-ink">Notifications</h1>
      <p className="mt-1 text-sm text-slate">Internal alerts and announcements for the admin team.</p>
      {status && <div className="mt-4"><Alert type={status.type}>{status.text}</Alert></div>}

      {role === 'admin' && (
        <form onSubmit={broadcast} className="mt-6 max-w-lg space-y-3 rounded-xl2 border border-line bg-white p-6 shadow-card">
          <p className="font-display text-lg text-ink">Broadcast a notification</p>
          <Input placeholder="Title" required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
          <textarea placeholder="Message" required value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} className="w-full rounded-lg border border-line px-3 py-2 text-sm" rows={2} />
          <div className="flex gap-2">
            <select value={form.severity} onChange={(e) => setForm({ ...form, severity: e.target.value })} className="rounded-lg border border-line px-3 py-2 text-sm">
              <option value="info">Info</option>
              <option value="warning">Warning</option>
              <option value="critical">Critical</option>
            </select>
            <select value={form.targetRole} onChange={(e) => setForm({ ...form, targetRole: e.target.value })} className="rounded-lg border border-line px-3 py-2 text-sm">
              <option value="">All roles</option>
              {ROLES.map((r) => <option key={r} value={r}>{r}</option>)}
            </select>
          </div>
          <Button type="submit">Send</Button>
        </form>
      )}

      <div className="mt-6 space-y-3">
        {items.map((n) => (
          <div key={n.id} className={`rounded-xl2 border border-line bg-white p-4 shadow-card ${n.is_read ? 'opacity-60' : ''}`}>
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${SEVERITY_STYLE[n.severity]}`}>{n.severity}</span>
                  <p className="text-sm font-medium text-ink">{n.title}</p>
                </div>
                <p className="mt-1 text-sm text-slate">{n.message}</p>
                <p className="mt-1 text-xs text-slate">{new Date(n.created_at).toLocaleString('en-NG')}</p>
              </div>
              {!n.is_read && <button onClick={() => markRead(n.id)} className="shrink-0 text-xs font-medium text-unlock underline">Mark read</button>}
            </div>
          </div>
        ))}
        {items.length === 0 && <p className="rounded-xl2 border border-line bg-white p-6 text-center text-sm text-slate shadow-card">No notifications yet.</p>}
      </div>
    </AdminShell>
  );
}
