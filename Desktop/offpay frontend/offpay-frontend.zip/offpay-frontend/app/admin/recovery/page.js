'use client';
import { useEffect, useState } from 'react';
import AdminShell from '../../../components/AdminShell';
import Alert from '../../../components/Alert';
import Button from '../../../components/Button';
import { adminFetch } from '../../../lib/adminApi';

const STATUSES = ['pending', 'approved', 'rejected', 'completed', 'all'];
const TYPE_LABEL = { password_reset: 'Password reset', pin_reset: 'PIN reset', device_change: 'Device change', account_lockout: 'Account lockout' };

export default function AdminRecoveryPage() {
  const [requests, setRequests] = useState([]);
  const [statusFilter, setStatusFilter] = useState('pending');
  const [status, setStatus] = useState(null);
  const [history, setHistory] = useState({}); // userId -> log entries
  const [expanded, setExpanded] = useState(null);
  const [tempValue, setTempValue] = useState({});

  useEffect(() => { load(); }, [statusFilter]);

  async function load() {
    try {
      const res = await adminFetch(`/admin/recovery-requests?status=${statusFilter}`);
      setRequests(res.data);
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    }
  }

  async function toggleHistory(userId) {
    if (expanded === userId) { setExpanded(null); return; }
    setExpanded(userId);
    if (!history[userId]) {
      try {
        const res = await adminFetch(`/admin/recovery-requests/user/${userId}`);
        setHistory((h) => ({ ...h, [userId]: res.data }));
      } catch (err) {
        setStatus({ type: 'error', text: err.message });
      }
    }
  }

  async function resolve(id, decision) {
    try {
      await adminFetch(`/admin/recovery-requests/${id}/resolve`, {
        method: 'POST',
        body: { decision, temporaryValue: tempValue[id] || undefined },
      });
      setStatus({ type: 'success', text: `Request ${decision}.` });
      load();
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    }
  }

  return (
    <AdminShell>
      <h1 className="font-display text-2xl text-ink">Recovery center</h1>
      <p className="mt-1 text-sm text-slate">Handles password/PIN reset requests, device-lockout recovery, and keeps a full history/log per user.</p>

      <div className="mt-4">
        <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="rounded-lg border border-line bg-white px-3 py-2.5 text-sm">
          {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
      </div>
      {status && <div className="mt-4"><Alert type={status.type}>{status.text}</Alert></div>}

      <div className="mt-6 space-y-4">
        {requests.map((r) => (
          <div key={r.id} className="rounded-xl2 border border-line bg-white p-5 shadow-card">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <p className="text-sm font-medium text-ink">{r.full_name} · {TYPE_LABEL[r.type] || r.type}</p>
                <p className="text-xs text-slate">{r.email} · {r.phone}</p>
                {r.reason && <p className="mt-1 text-sm text-slate">"{r.reason}"</p>}
                <p className="mt-1 text-xs text-slate">Requested {new Date(r.created_at).toLocaleString('en-NG')}</p>
              </div>
              <span className="rounded-full bg-paper px-2.5 py-1 text-xs font-medium capitalize text-ink">{r.status}</span>
            </div>

            {r.status === 'pending' && (
              <div className="mt-4 space-y-2 border-t border-line pt-4">
                {(r.type === 'password_reset' || r.type === 'pin_reset') && (
                  <input
                    type="text" placeholder={r.type === 'pin_reset' ? 'Temporary 4-digit PIN' : 'Temporary password'}
                    value={tempValue[r.id] || ''} onChange={(e) => setTempValue({ ...tempValue, [r.id]: e.target.value })}
                    className="w-full max-w-xs rounded-lg border border-line px-3 py-2 text-sm"
                  />
                )}
                <div className="flex flex-wrap gap-2">
                  <Button variant="accent" onClick={() => resolve(r.id, 'approved')}>Approve &amp; reset</Button>
                  <Button variant="ghost" onClick={() => resolve(r.id, 'rejected')}>Reject</Button>
                </div>
              </div>
            )}

            <button onClick={() => toggleHistory(r.user_id)} className="mt-3 text-xs font-medium text-unlock underline">
              {expanded === r.user_id ? 'Hide' : 'View'} recovery history for this user
            </button>

            {expanded === r.user_id && (
              <div className="mt-2 space-y-1.5 rounded-lg bg-paper p-3">
                {(history[r.user_id] || []).map((h) => (
                  <p key={h.id} className="text-xs text-slate">
                    {new Date(h.created_at).toLocaleDateString('en-NG')} · {TYPE_LABEL[h.type] || h.type} · <span className="font-medium capitalize text-ink">{h.status}</span>
                    {h.handled_by_name && ` · handled by ${h.handled_by_name}`}
                  </p>
                ))}
                {(history[r.user_id] || []).length === 0 && <p className="text-xs text-slate">No prior requests.</p>}
              </div>
            )}
          </div>
        ))}
        {requests.length === 0 && <p className="rounded-xl2 border border-line bg-white p-6 text-center text-sm text-slate shadow-card">No requests here.</p>}
      </div>
    </AdminShell>
  );
}
