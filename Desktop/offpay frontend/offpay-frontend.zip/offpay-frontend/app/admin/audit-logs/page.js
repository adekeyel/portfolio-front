'use client';
import { useEffect, useState } from 'react';
import AdminShell from '../../../components/AdminShell';
import { adminFetch } from '../../../lib/adminApi';

export default function AuditLogsPage() {
  const [logs, setLogs] = useState([]);

  useEffect(() => {
    adminFetch('/admin/audit-logs?limit=200').then((res) => setLogs(res.data)).catch(() => {});
  }, []);

  return (
    <AdminShell>
      <h1 className="font-display text-2xl text-ink">Audit logs</h1>
      <div className="mt-6 overflow-x-auto rounded-xl2 border border-line bg-white shadow-card">
        <table className="w-full text-sm">
          <thead className="bg-paper text-left text-xs uppercase tracking-wide text-slate">
            <tr>
              <th className="px-5 py-3">When</th>
              <th className="px-5 py-3">Actor</th>
              <th className="px-5 py-3">Action</th>
              <th className="px-5 py-3">Target</th>
            </tr>
          </thead>
          <tbody>
            {logs.map((l) => (
              <tr key={l.id} className="border-t border-line">
                <td className="px-5 py-3 text-slate">{new Date(l.created_at).toLocaleString('en-NG')}</td>
                <td className="px-5 py-3">{l.actor_type}</td>
                <td className="px-5 py-3 font-medium text-ink">{l.action}</td>
                <td className="px-5 py-3 font-mono text-xs text-slate">{l.target_type ? `${l.target_type}:${l.target_id}` : '—'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </AdminShell>
  );
}
