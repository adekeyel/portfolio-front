'use client';
import { useEffect, useState } from 'react';
import AdminShell from '../../../components/AdminShell';
import Alert from '../../../components/Alert';
import Input from '../../../components/Input';
import { adminFetch, getAdminInfo } from '../../../lib/adminApi';

const STATUSES = ['all', 'pending', 'success', 'failed', 'reversed', 'queued_offline'];

export default function AdminTransactionsPage() {
  const [txns, setTxns] = useState([]);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [status, setStatus] = useState(null);
  const [reasonModal, setReasonModal] = useState(null);
  const [reason, setReason] = useState('');
  const role = getAdminInfo()?.role;
  const canReverse = role === 'admin' || role === 'finance';

  useEffect(() => { load(); }, [search, statusFilter]);

  async function load() {
    try {
      const params = new URLSearchParams();
      if (search) params.set('search', search);
      if (statusFilter !== 'all') params.set('status', statusFilter);
      const res = await adminFetch(`/admin/transactions?${params.toString()}`);
      setTxns(res.data);
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    }
  }

  async function confirmReverse() {
    try {
      await adminFetch(`/admin/transactions/${reasonModal.id}/reverse`, { method: 'POST', body: { reason } });
      setStatus({ type: 'success', text: 'Transaction reversed.' });
      setReasonModal(null);
      setReason('');
      load();
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    }
  }

  return (
    <AdminShell>
      <h1 className="font-display text-2xl text-ink">Transactions</h1>
      <div className="mt-4 flex flex-wrap items-end gap-3">
        <div className="max-w-sm flex-1">
          <Input placeholder="Search reference, user, narration…" value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <label className="block">
          <span className="mb-1.5 block text-xs font-medium text-slate">Status</span>
          <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="rounded-lg border border-line bg-white px-3 py-2.5 text-sm">
            {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
        </label>
      </div>
      {status && <div className="mt-4"><Alert type={status.type}>{status.text}</Alert></div>}

      <div className="mt-6 overflow-x-auto rounded-xl2 border border-line bg-white shadow-card">
        <table className="w-full whitespace-nowrap text-sm">
          <thead className="bg-paper text-left text-xs uppercase tracking-wide text-slate">
            <tr>
              <th className="px-3 py-3">Time</th>
              <th className="px-3 py-3">User ID</th>
              <th className="px-3 py-3">Reference</th>
              <th className="px-3 py-3">Narration</th>
              <th className="px-3 py-3">Sender</th>
              <th className="px-3 py-3">Receiver</th>
              <th className="px-3 py-3">Bank</th>
              <th className="px-3 py-3">Amount</th>
              <th className="px-3 py-3">Fee</th>
              <th className="px-3 py-3">Status</th>
              {canReverse && <th className="px-3 py-3"></th>}
            </tr>
          </thead>
          <tbody>
            {txns.map((t) => (
              <tr key={t.id} className="border-t border-line">
                <td className="px-3 py-3 text-slate">{new Date(t.time).toLocaleString('en-NG')}</td>
                <td className="px-3 py-3 font-mono text-xs">{t.user_id}</td>
                <td className="px-3 py-3 font-mono text-xs">{t.reference}</td>
                <td className="px-3 py-3 max-w-[16rem] truncate text-slate">{t.narration}</td>
                <td className="px-3 py-3">{t.sender || '—'}</td>
                <td className="px-3 py-3">{t.receiver || '—'}</td>
                <td className="px-3 py-3 text-slate">{t.bank || '—'}</td>
                <td className="px-3 py-3 font-mono">₦{Number(t.amount).toLocaleString()}</td>
                <td className="px-3 py-3 font-mono text-slate">₦{Number(t.fee).toLocaleString()}</td>
                <td className="px-3 py-3">
                  <span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${t.status === 'success' ? 'bg-unlock-dim text-unlock' : t.status === 'failed' || t.status === 'reversed' ? 'bg-red-50 text-danger' : 'bg-amber-50 text-amber-700'}`}>
                    {t.status}
                  </span>
                </td>
                {canReverse && (
                  <td className="px-3 py-3">
                    {t.status === 'success' && (
                      <button onClick={() => setReasonModal({ id: t.id })} className="text-xs font-medium text-danger underline">Reverse</button>
                    )}
                  </td>
                )}
              </tr>
            ))}
            {txns.length === 0 && <tr><td colSpan={11} className="p-6 text-center text-sm text-slate">No transactions found.</td></tr>}
          </tbody>
        </table>
      </div>

      {reasonModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
          <div className="w-full max-w-sm space-y-3 rounded-xl2 bg-white p-6 shadow-card">
            <p className="text-sm font-medium text-ink">Reason to reverse this transaction:</p>
            <textarea value={reason} onChange={(e) => setReason(e.target.value)} className="w-full rounded-lg border border-line px-3 py-2 text-sm" rows={3} />
            <div className="flex gap-2">
              <button onClick={confirmReverse} className="rounded-lg bg-danger px-4 py-2 text-sm font-semibold text-white">Confirm</button>
              <button onClick={() => setReasonModal(null)} className="rounded-lg border border-line px-4 py-2 text-sm">Cancel</button>
            </div>
          </div>
        </div>
      )}
    </AdminShell>
  );
}
