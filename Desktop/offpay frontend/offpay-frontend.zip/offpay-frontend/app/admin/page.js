'use client';
import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { getAdminInfo } from '../../lib/adminApi';

/**
 * Entry point for admin access, now reached by navigating to /admin directly
 * instead of a public link in the landing page footer. Renders nothing —
 * just routes to the dashboard if a staff session is already active, or to
 * the login screen otherwise.
 */
export default function AdminEntryPage() {
  const router = useRouter();

  useEffect(() => {
    router.replace(getAdminInfo() ? '/admin/dashboard' : '/admin/login');
  }, [router]);

  return null;
}
