'use client';
import { useEffect, useState } from 'react';
import AdminShell from '../../../components/AdminShell';
import Alert from '../../../components/Alert';
import Button from '../../../components/Button';
import { adminFetch } from '../../../lib/adminApi';

export default function AdminFeesPage() {
  const [fees, setFees] = useState([]);
  const [editing, setEditing] = useState({});
  const [status, setStatus] = useState(null);

  useEffect(() => { load(); }, []);

  async function load() {
    try {
      const res = await adminFetch('/admin/fees');
      setFees(res.data);
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    }
  }

  async function save(id) {
    try {
      await adminFetch(`/admin/fees/${id}`, { method: 'PATCH', body: { feeValue: parseFloat(editing[id]) } });
      setStatus({ type: 'success', text: 'Fee updated.' });
      load();
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    }
  }

  return (
    <AdminShell>
      <h1 className="font-display text-2xl text-ink">Fee configuration</h1>
      <p className="mt-1 text-sm text-slate">Adjust transaction fees applied across the platform.</p>
      {status && <div className="mt-4"><Alert type={status.type}>{status.text}</Alert></div>}

      <div className="mt-6 overflow-hidden rounded-xl2 border border-line bg-white shadow-card">
        <table className="w-full text-sm">
          <thead className="bg-paper text-left text-xs uppercase tracking-wide text-slate">
            <tr>
              <th className="px-5 py-3">Fee</th>
              <th className="px-5 py-3">Range</th>
              <th className="px-5 py-3">Type</th>
              <th className="px-5 py-3">Value</th>
              <th className="px-5 py-3"></th>
            </tr>
          </thead>
          <tbody>
            {fees.map((f) => (
              <tr key={f.id} className="border-t border-line">
                <td className="px-5 py-3 font-medium text-ink">{f.label}</td>
                <td className="px-5 py-3 text-slate">₦{Number(f.min_amount).toLocaleString()} – {f.max_amount ? `₦${Number(f.max_amount).toLocaleString()}` : '∞'}</td>
                <td className="px-5 py-3 capitalize text-slate">{f.fee_type}</td>
                <td className="px-5 py-3">
                  <input
                    type="number" defaultValue={f.fee_value}
                    onChange={(e) => setEditing({ ...editing, [f.id]: e.target.value })}
                    className="w-24 rounded-lg border border-line px-2 py-1 font-mono text-sm"
                  />
                </td>
                <td className="px-5 py-3"><Button variant="ghost" onClick={() => save(f.id)}>Save</Button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </AdminShell>
  );
}
