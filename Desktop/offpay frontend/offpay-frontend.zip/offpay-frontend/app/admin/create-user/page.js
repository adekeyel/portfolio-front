'use client';
import { useState } from 'react';
import AdminShell from '../../../components/AdminShell';
import Input from '../../../components/Input';
import Button from '../../../components/Button';
import Alert from '../../../components/Alert';
import { adminFetch } from '../../../lib/adminApi';

const ROLES = ['admin', 'support', 'compliance', 'finance', 'operations', 'fraud', 'recovery'];
const ROLE_DESCRIPTIONS = {
  admin: 'Super admin — full access to every module.',
  support: 'Accounts (read-only) and support tickets/live chat.',
  compliance: 'KYC review, account actions, audit logs, closed accounts.',
  finance: 'Overview revenue figures, accounts, transactions, wallet (view only).',
  operations: 'General account visibility for provider/virtual-account operations.',
  fraud: 'Fraud monitoring, transaction visibility, account visibility.',
  recovery: 'Recovery center — password/PIN reset and lockout requests.',
};

export default function CreateUserPage() {
  const [form, setForm] = useState({ fullName: '', email: '', password: '', role: 'support' });
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setStatus(null);
    setLoading(true);
    try {
      await adminFetch('/admin/admins', { method: 'POST', body: form });
      setStatus({ type: 'success', text: `Staff account created with role: ${form.role}. They can find it under Staff.` });
      setForm({ fullName: '', email: '', password: '', role: 'support' });
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    } finally {
      setLoading(false);
    }
  }

  return (
    <AdminShell>
      <h1 className="font-display text-2xl text-ink">Create users</h1>
      <p className="mt-1 text-sm text-slate">Create a new staff/admin account with a scoped role. Manage existing staff under the Staff page.</p>

      <form onSubmit={submit} className="mt-6 max-w-md space-y-4 rounded-xl2 border border-line bg-white p-6 shadow-card">
        <Input label="Full name" required value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} />
        <Input label="Email" type="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
        <Input label="Temporary password" type="password" required minLength={8} value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
        <label className="block">
          <span className="mb-1.5 block text-sm font-medium text-ink">Role</span>
          <select value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })} className="w-full rounded-lg border border-line bg-white px-3.5 py-2.5 text-sm">
            {ROLES.map((r) => <option key={r} value={r}>{r}</option>)}
          </select>
          <span className="mt-1.5 block text-xs text-slate">{ROLE_DESCRIPTIONS[form.role]}</span>
        </label>
        {status && <Alert type={status.type}>{status.text}</Alert>}
        <Button type="submit" className="w-full" disabled={loading}>{loading ? 'Creating…' : 'Create account'}</Button>
      </form>
    </AdminShell>
  );
}
