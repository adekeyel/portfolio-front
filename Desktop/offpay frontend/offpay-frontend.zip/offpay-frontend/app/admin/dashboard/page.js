'use client';
import { useEffect, useState } from 'react';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import AdminShell from '../../../components/AdminShell';
import StatCard from '../../../components/StatCard';
import { adminFetch, getAdminInfo } from '../../../lib/adminApi';

const PIE_COLORS = ['#0f172a', '#16a34a', '#f59e0b'];

export default function AdminDashboardPage() {
  const [stats, setStats] = useState(null);
  const role = getAdminInfo()?.role;

  useEffect(() => {
    adminFetch('/admin/dashboard/stats').then((res) => setStats(res.data)).catch(() => {});
  }, []);

  if (!stats) {
    return (
      <AdminShell>
        <h1 className="font-display text-2xl text-ink">Overview</h1>
        <p className="mt-4 text-sm text-slate">Loading…</p>
      </AdminShell>
    );
  }

  const fmt = (n) => `₦${Number(n || 0).toLocaleString()}`;

  return (
    <AdminShell>
      <h1 className="font-display text-2xl text-ink">Overview</h1>
      <p className="mt-1 text-sm text-slate">{role === 'admin' ? 'Full platform visibility.' : "Here's what's happening today."}</p>

      {/* Treasury numbers — super admin + finance only */}
      {stats.finance ? (
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label="Total wallet balance" value={fmt(stats.finance.totalWalletBalance)} sub={`${stats.finance.walletCount} wallets`} />
          <StatCard label="Volume — day / week / month" value={fmt(stats.finance.volume.day)} sub={`${fmt(stats.finance.volume.week)} this week · ${fmt(stats.finance.volume.month)} this month`} />
          <StatCard label="Fee revenue (day)" value={fmt(stats.finance.feeRevenue.day)} accent="unlock" sub={`${fmt(stats.finance.feeRevenue.week)} this week · ${fmt(stats.finance.feeRevenue.month)} this month`} />
          <StatCard label="Pending KYC" value={stats.pendingKyc} accent="lock" />
        </div>
      ) : (
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label="Wallet balance (today)" value={fmt(stats.todayVolume)} sub="Today's transaction volume only" />
          <StatCard label="Pending KYC" value={stats.pendingKyc} accent="lock" />
          <StatCard label="Open tickets" value={stats.openTickets} />
          <StatCard label="Fraud alerts (open)" value={stats.fraudAlerts} accent="danger" />
        </div>
      )}

      <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Total users" value={stats.totalUsers} />
        <StatCard label="Active today" value={stats.activeToday} />
        <StatCard label="Total transactions" value={stats.totalTransactions} />
        <StatCard label="Today's transactions" value={stats.todayTransactions} />
      </div>
      <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Successful" value={stats.successful} accent="unlock" />
        <StatCard label="Failed / reversed" value={stats.failedOrReversed} accent="danger" />
        <StatCard label="Pending" value={stats.pending} />
        {stats.finance && <StatCard label="Open tickets / fraud alerts" value={`${stats.openTickets} / ${stats.fraudAlerts}`} />}
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-2">
        <div className="rounded-xl2 border border-line bg-white p-6 shadow-card">
          <h2 className="font-display text-lg text-ink">Daily transactions</h2>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={stats.charts.dailyTransactions}>
              <CartesianGrid strokeDasharray="3 3" stroke="#eee" />
              <XAxis dataKey="date" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
              <Tooltip />
              <Line type="monotone" dataKey="count" stroke="#0f172a" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="rounded-xl2 border border-line bg-white p-6 shadow-card">
          <h2 className="font-display text-lg text-ink">Daily volume (₦)</h2>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={stats.charts.dailyVolume}>
              <CartesianGrid strokeDasharray="3 3" stroke="#eee" />
              <XAxis dataKey="date" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip formatter={(v) => fmt(v)} />
              <Bar dataKey="amount" fill="#16a34a" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="rounded-xl2 border border-line bg-white p-6 shadow-card">
          <h2 className="font-display text-lg text-ink">User growth</h2>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={stats.charts.userGrowth}>
              <CartesianGrid strokeDasharray="3 3" stroke="#eee" />
              <XAxis dataKey="date" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
              <Tooltip />
              <Line type="monotone" dataKey="count" stroke="#f59e0b" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="rounded-xl2 border border-line bg-white p-6 shadow-card">
          <h2 className="font-display text-lg text-ink">KYC tier distribution</h2>
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie data={stats.charts.kycTierDistribution} dataKey="count" nameKey="tier" outerRadius={80} label>
                {stats.charts.kycTierDistribution.map((entry, i) => <Cell key={entry.tier} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>
    </AdminShell>
  );
}
