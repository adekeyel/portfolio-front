'use client';
import { useEffect, useState } from 'react';
import AdminShell from '../../../components/AdminShell';
import Alert from '../../../components/Alert';
import Button from '../../../components/Button';
import { adminFetch } from '../../../lib/adminApi';

export default function SettingsPage() {
  const [fees, setFees] = useState([]);
  const [feeEditing, setFeeEditing] = useState({});
  const [settings, setSettings] = useState([]);
  const [settingsEditing, setSettingsEditing] = useState({});
  const [status, setStatus] = useState(null);

  useEffect(() => { load(); }, []);

  async function load() {
    try {
      const [feeRes, settingsRes] = await Promise.all([
        adminFetch('/admin/fees'),
        adminFetch('/admin/settings'),
      ]);
      setFees(feeRes.data);
      setSettings(settingsRes.data);
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    }
  }

  async function saveFee(id) {
    try {
      await adminFetch(`/admin/fees/${id}`, { method: 'PATCH', body: { feeValue: parseFloat(feeEditing[id]) } });
      setStatus({ type: 'success', text: 'Fee updated.' });
      load();
    } catch (err) {
      setStatus({ type: 'error', text: err.message });
    }
  }

  async function saveSetting(key) {
    try {
      const raw = settingsEditing[key];
      const value = JSON.parse(raw);
      await adminFetch(`/admin/settings/${key}`, { method: 'PATCH', body: { value } });
      setStatus({ type: 'success', text: 'Setting updated.' });
      load();
    } catch (err) {
      setStatus({ type: 'error', text: err.message.includes('JSON') ? 'That value is not valid JSON.' : err.message });
    }
  }

  return (
    <AdminShell>
      <h1 className="font-display text-2xl text-ink">Settings</h1>
      <p className="mt-1 text-sm text-slate">Super-admin only — platform policies: transaction fees, withdrawal limits, and KYC tier requirements.</p>
      {status && <div className="mt-4"><Alert type={status.type}>{status.text}</Alert></div>}

      <div className="mt-6 overflow-hidden rounded-xl2 border border-line bg-white shadow-card">
        <div className="border-b border-line px-5 py-4"><h2 className="font-display text-lg text-ink">Transaction fees</h2></div>
        <table className="w-full text-sm">
          <thead className="bg-paper text-left text-xs uppercase tracking-wide text-slate">
            <tr>
              <th className="px-5 py-3">Fee</th>
              <th className="px-5 py-3">Range</th>
              <th className="px-5 py-3">Type</th>
              <th className="px-5 py-3">Value</th>
              <th className="px-5 py-3"></th>
            </tr>
          </thead>
          <tbody>
            {fees.map((f) => (
              <tr key={f.id} className="border-t border-line">
                <td className="px-5 py-3 font-medium text-ink">{f.label}</td>
                <td className="px-5 py-3 text-slate">₦{Number(f.min_amount).toLocaleString()} – {f.max_amount ? `₦${Number(f.max_amount).toLocaleString()}` : '∞'}</td>
                <td className="px-5 py-3 capitalize text-slate">{f.fee_type}</td>
                <td className="px-5 py-3">
                  <input
                    type="number" defaultValue={f.fee_value}
                    onChange={(e) => setFeeEditing({ ...feeEditing, [f.id]: e.target.value })}
                    className="w-24 rounded-lg border border-line px-2 py-1 font-mono text-sm"
                  />
                </td>
                <td className="px-5 py-3"><Button variant="ghost" onClick={() => saveFee(f.id)}>Save</Button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="mt-6 space-y-4">
        <h2 className="font-display text-lg text-ink">Withdrawal limits &amp; KYC tier requirements</h2>
        {settings.map((s) => (
          <div key={s.key} className="rounded-xl2 border border-line bg-white p-5 shadow-card">
            <p className="text-sm font-medium text-ink">{s.label}</p>
            <p className="mt-0.5 font-mono text-xs text-slate">{s.key}</p>
            <textarea
              defaultValue={JSON.stringify(s.value, null, 2)}
              onChange={(e) => setSettingsEditing({ ...settingsEditing, [s.key]: e.target.value })}
              className="mt-2 w-full rounded-lg border border-line px-3 py-2 font-mono text-xs"
              rows={4}
            />
            <Button variant="ghost" className="mt-2" onClick={() => saveSetting(s.key)}>Save</Button>
          </div>
        ))}
      </div>
    </AdminShell>
  );
}
